"""
Read using python
=================
Defines class Read, which is used to read data from amorphic datalake backed by s3.
"""

import boto3
import pandas as pd

import amorphicutils.awshelper
from amorphicutils.amorphiclogging import Log4j
from typing import Optional, Union, List


class Read:
    """
    Class to read data from Amorphic
    """

    def __init__(self, bucket_name, region=None, logger=None):
        """
        Initialize the class with dataset specific details

        :param bucket_name: name of the bucket

        >>> reader = Read("dlz_bucket")
        """
        if region:
            self.s3_resource = boto3.resource("s3", region)
        else:
            self.s3_resource = boto3.resource("s3")
        self.region = region
        self.bucket = self.s3_resource.Bucket(bucket_name)
        self.bucket_name = bucket_name
        self._logger = logger if logger else Log4j().get_logger()

    @staticmethod
    def _get_prefix(domain_name, dataset_name, upload_date=None):
        """
        returns the prefix for data to read
        :param domain_name:
        :param dataset_name:
        :param upload_date:
        :return:
        """

        full_s3_path = "/".join([domain_name, dataset_name, ""])
        if not upload_date:
            _prefix = full_s3_path
        else:
            _prefix = full_s3_path + "upload_date=" + str(upload_date) + "/"
        return _prefix

    def list_object(self, domain_name, dataset_name):
        """
        List the objects for specific datasets

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :return: list of objects from s3

        >>> reader = Read("dlz_bucket")
        >>> reader.list_object("testdomain", "testdataset")
        """
        _prefix = domain_name + "/" + dataset_name + "/"
        return amorphicutils.awshelper.list_bucket_objects(
            self.bucket_name, _prefix, self.region
        )

    # pylint: disable=too-many-locals,too-many-branches
    def read_csv_data(
        self,
        domain_name,
        dataset_name,
        schema=None,
        header=False,
        delimiter=",",
        upload_date=None,
        path=None,
        **kwargs
    ):
        """
        Read csv data from s3 using pandas dataframe read api and generate pandas dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param schema: List of col names of the data.
        :type: list(str)
        :param header: True if data files contains header. Default: False
        :param delimiter: delimiter in the dataset. Default: ","
        :param upload_date: upload date timestamp.
        :param path: Path of the file to read from.
        :param kwargs: Optional arguments available for python pandas csv read

        :return:

        >>> reader = Read("dlz_bucket")
        >>> df = reader.read_csv_data("testdomain", "testdataset", upload_date="1578305347")
        """

        try:
            self._logger.info(
                "In Read.read_csv_data Reading csv data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)

            if header:
                pd_header = 0
            else:
                pd_header = None

            final_df = pd.DataFrame()

            if path:
                if schema:
                    pd_df = pd.read_csv(
                        _prefix, sep=delimiter, header=pd_header, names=schema, **kwargs
                    )
                else:
                    pd_df = pd.read_csv(
                        _prefix, sep=delimiter, header=pd_header, **kwargs
                    )
                final_df = pd_df
                response = {
                    "exitcode": 0,
                    "message": "Successfully loaded s3 data into pandas dataframe",
                    "data": final_df,
                }
            else:
                objs = amorphicutils.awshelper.list_bucket_objects(
                    self.bucket_name, _prefix, self.region
                )
                if objs:
                    for obj in objs:
                        _key = obj["Key"]
                        _full_key = "s3://{0}/{1}".format(self.bucket_name, _key)

                        if schema:
                            pd_df = pd.read_csv(
                                _full_key, sep=delimiter, header=pd_header, names=schema
                            )
                        else:
                            pd_df = pd.read_csv(
                                _full_key, sep=delimiter, header=pd_header
                            )

                        final_df = pd.concat([final_df, pd_df])

                    response = {
                        "exitcode": 0,
                        "message": "Successfully loaded s3 data into pandas dataframe",
                        "data": final_df,
                    }
                else:
                    response = {
                        "exitcode": 1,
                        "message": "No data available for prefix {}".format(_prefix),
                        "data": None,
                    }

        except Exception as ex:
            response = {"exitcode": 1, "message": ex, "data": None}
        return response

    # pylint: disable=too-many-locals,too-many-branches
    def read_parquet(
        self, domain_name, dataset_name, upload_date=None, path=None, **kwargs
    ):
        """
        Read parquet data from s3 using pandas dataframe read api and generate pandas dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param upload_date: upload date timestamp.
        :param path: Path of the file to read from.
        :param kwargs: Optional arguments available for python pandas parquet read

        :return:

        >>> reader = Read("dlz_bucket")
        >>> df = reader.read_parquet("testdomain", "testdataset", upload_date="1578305347")
        """

        try:
            self._logger.info(
                "In Read.read_parquet Reading parquet data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)

            final_df = pd.DataFrame()

            if path:
                pd_df = pd.read_parquet(_prefix, **kwargs)
                final_df = pd_df
                response = {
                    "exitcode": 0,
                    "message": "Successfully loaded s3 data into pandas dataframe",
                    "data": final_df,
                }
            else:
                objs = amorphicutils.awshelper.list_bucket_objects(
                    self.bucket_name, _prefix, self.region
                )
                if objs:
                    for obj in objs:
                        _key = obj["Key"]
                        _full_key = "s3://{0}/{1}".format(self.bucket_name, _key)
                        pd_df = pd.read_parquet(_full_key, **kwargs)
                        final_df = pd.concat([final_df, pd_df])

                    response = {
                        "exitcode": 0,
                        "message": "Successfully loaded s3 data into pandas dataframe",
                        "data": final_df,
                    }
                else:
                    response = {
                        "exitcode": 1,
                        "message": "No data available for prefix {}".format(_prefix),
                        "data": None,
                    }

        except Exception as ex:
            response = {"exitcode": 1, "message": ex, "data": None}
        return response

    def read_excel(
        self,
        domain_name,
        dataset_name,
        sheet_name=0,
        header=False,
        schema=None,
        upload_date=None,
        path=None,
        **kwargs
    ):
        """
        Read data from excel files and return pandas dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param sheet_name: sheet name or indices to read data from. Default: 0
        :param header: True if data files contains header. Default: False
        :param schema: List of col names of the data.
        :param upload_date: upload date timestamp.
        :param path: Path of the file to read from.
        :param kwargs: Optional arguments available for python pandas excel read

        :return:

        >>> amorphic_reader = Read(bucket_name="dlz_bucket")
        >>> result = amorphic_reader.read_excel(domain_name="testdomain", dataset_name="testdataset", header=True)
        """

        try:
            self._logger.info(
                "In Read.read_excel Reading excel data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)

            if header:
                pd_header = 0
            else:
                pd_header = None

            final_df = pd.DataFrame()

            if path:
                if schema:
                    pd_df = pd.read_excel(
                        _prefix,
                        sheet_name=sheet_name,
                        header=pd_header,
                        names=schema,
                        **kwargs
                    )
                else:
                    pd_df = pd.read_excel(
                        _prefix, sheet_name=sheet_name, header=pd_header, **kwargs
                    )
                final_df = pd_df
                response = {
                    "exitcode": 0,
                    "message": "Successfully loaded s3 data into pandas dataframe",
                    "data": final_df,
                }
            else:
                objs = amorphicutils.awshelper.list_bucket_objects(
                    self.bucket_name, _prefix, self.region
                )
                if objs:
                    for obj in objs:
                        _key = obj["Key"]
                        _full_key = "s3://{0}/{1}".format(self.bucket_name, _key)

                        if schema:
                            pd_df = pd.read_excel(
                                _full_key,
                                sheet_name=sheet_name,
                                header=pd_header,
                                names=schema,
                                **kwargs
                            )
                        else:
                            pd_df = pd.read_excel(
                                _full_key,
                                sheet_name=sheet_name,
                                header=pd_header,
                                **kwargs
                            )

                        final_df = pd.concat([final_df, pd_df])

                    response = {
                        "exitcode": 0,
                        "message": "Successfully loaded s3 data into pandas dataframe",
                        "data": final_df,
                    }
                else:
                    response = {
                        "exitcode": 1,
                        "message": "No data available for prefix {}".format(_prefix),
                        "data": None,
                    }

        except Exception as ex:
            self._logger.error(
                "Failed to read excel file with error: {error}".format(error=ex)
            )
            response = {"exitcode": 1, "message": ex, "data": None}
        return response

    def read_json(
        self, domain_name, dataset_name, upload_date=None, path=None, **kwargs
    ):
        """
        Read data from excel files and return pandas dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param upload_date: upload date timestamp.
        :param path: Path of the file to read from.
        :param kwargs: Optional arguments available for python pandas json read

        :return:

        >>> amorphic_reader = Read(bucket_name="dlz_bucket")
        >>> result = amorphic_reader.read_json(domain_name="testdomain", dataset_name="testdataset")
        """

        try:
            self._logger.info(
                "In Read.read_json Reading json data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)

            final_df = pd.DataFrame()

            if path:
                pd_df = pd.read_json(_prefix, **kwargs)
                final_df = pd_df
                response = {
                    "exitcode": 0,
                    "message": "Successfully loaded s3 data into pandas dataframe",
                    "data": final_df,
                }
            else:
                objs = amorphicutils.awshelper.list_bucket_objects(
                    self.bucket_name, _prefix, self.region
                )
                if objs:
                    for obj in objs:
                        _key = obj["Key"]
                        _full_key = "s3://{0}/{1}".format(self.bucket_name, _key)

                        pd_df = pd.read_json(_full_key, **kwargs)

                        final_df = pd.concat([final_df, pd_df])

                    response = {
                        "exitcode": 0,
                        "message": "Successfully loaded s3 data into pandas dataframe",
                        "data": final_df,
                    }
                else:
                    response = {
                        "exitcode": 1,
                        "message": "No data available for prefix {}".format(_prefix),
                        "data": None,
                    }

        except Exception as ex:
            self._logger.error(
                "Failed to read json file with error: {error}".format(error=ex)
            )
            response = {"exitcode": 1, "message": ex, "data": None}
        return response
