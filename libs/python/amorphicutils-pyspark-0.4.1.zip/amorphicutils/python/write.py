"""
Wite using python
=================
Defines class Write, which is used to write data to amorphic datalake backed by s3.
"""

import csv
import time
import boto3
from amorphicutils import awshelper
from amorphicutils.errors import DataNotInBytesException
from amorphicutils.common import WriteUtil, bool_retry
from amorphicutils.datalakeutil import DataLandingZoneUtil
from amorphicutils.amorphiclogging import Log4j


class Write(WriteUtil, DataLandingZoneUtil):
    """
    Class to write data from Amorphic
    """

    def __init__(self, bucket_name, region=None):
        """
        Initialize the Write object

        :param bucket_name: bucket name


        >>> writer = Write("lz_bucket")
        """

        if region:
            self.s3_resource = boto3.resource("s3", region)
        else:
            self.s3_resource = boto3.resource("s3")
        self.region = region
        self.bucket = self.s3_resource.Bucket(bucket_name)
        self.bucket_name = bucket_name
        self._logger = Log4j().get_logger()
        WriteUtil.__init__(self, bucket_name, region)
        dlz_bucket = "-".join(bucket_name.split("-")[0:-1] + ["dlz"])
        DataLandingZoneUtil.__init__(
            self, lz_bucket_name=bucket_name, dlz_bucket_name=dlz_bucket, region=region
        )

    @staticmethod
    def _get_prefix(
        domain_name, dataset_name, user, file_type, upload_date=None, file_name=None
    ):
        """
        returns the prefix for data to read
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: UserId who has permission to upload data
        :param file_type: Type of data in the dataset. For ex., csv, pdf, png
        :param upload_date: date to use to upload the data
        :param file_name: Name of the file
        :return:
        """

        if upload_date:
            _upload_date = str(int(upload_date))
        else:
            _upload_date = str(int(time.time()))

        _prefix = "/".join(
            [
                domain_name,
                dataset_name,
                "upload_date=" + _upload_date,
                user,
                file_type,
                "{0}_{1}_{2}".format(dataset_name, user, _upload_date)
                if not file_name
                else file_name,
            ]
        )

        return _upload_date, _prefix

    # pylint: disable=too-many-arguments,too-many-locals
    def write_csv_data(
        self,
        data,
        domain_name,
        dataset_name,
        user,
        header=True,
        file_type="csv",
        quote=True,
        delimiter=",",
        upload_date=None,
        full_reload=False,
        path=None,
        file_name=None,
        **kwargs
    ):
        """
        Write data to lz bucket

        :param data: pandas dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param header: True if you want to save file with header. Default: True
        :param file_type: file type for dataset
        :param quote: True if you want to save you data with quoted character. Default: True
        :param delimiter: Delimiter to use to save to s3. Default: ,
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param file_name: Name of the file
        :param kwargs: Optional arguments available for pyspark read

        :return:

        >>> writer = Write("lz_bucket")
        >>> response = writer.write_csv_data(pandas_df, "testdomain", "testdataset", user="userid", file_type="csv")
        >>> print(response)
        >>> {
          "exitcode": 0,
          "message": "This is success message"
          }
        """

        try:
            self._logger.info(
                "In Write.write_csv_data, Writing csv data to dataset {0}.{1}".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path

                if quote:
                    data.to_csv(
                        _prefix,
                        index=False,
                        header=header,
                        sep=delimiter,
                        quotechar='"',
                        quoting=csv.QUOTE_ALL,
                        **kwargs
                    )
                else:
                    data.to_csv(
                        _prefix, index=False, header=header, sep=delimiter, **kwargs
                    )
            else:
                upload_date, _prefix = self._get_prefix(
                    domain_name, dataset_name, user, file_type, upload_date, file_name
                )

                _prefix = _prefix + ".csv"

                if quote:
                    bytes_to_write = data.to_csv(
                        index=False,
                        header=header,
                        sep=delimiter,
                        quotechar='"',
                        quoting=csv.QUOTE_ALL,
                        encoding="utf-8",
                        **kwargs
                    )
                else:
                    bytes_to_write = data.to_csv(
                        index=False,
                        header=header,
                        sep=delimiter,
                        encoding="utf-8",
                        **kwargs
                    )

                awshelper.put_object(
                    self.bucket_name, _prefix, bytes_to_write.encode("utf-8")
                )

            if full_reload:
                result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                    bucket_name=self.bucket_name,
                    domain_name=domain_name,
                    dataset_name=dataset_name,
                    upload_date=upload_date,
                    path=path,
                    region=self.region,
                )
                if result:
                    self.send_success_file(
                        domain_name, dataset_name, user, file_type, prefix=_prefix
                    )
                    # super(Write, self).send_success_file(domain_name, dataset_name, user, file_type)
                else:
                    raise Exception(
                        "Failed to upload _SUCCESS file to trigger reload. Please trigger from UI."
                    )

            response = {"exitcode": 0, "message": "Successfully saved data to s3."}
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response

    def write_bytes_data(
        self,
        data_bytes,
        domain_name,
        dataset_name,
        user,
        file_type,
        upload_date=None,
        full_reload=False,
        path=None,
        file_name=None,
    ):
        """
        Writes bytes data to datalake

        :param data_bytes: data bytes to write
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param file_type: file type of the dataset
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param file_name: Name of the file

        :return:
        """

        try:
            if not isinstance(data_bytes, bytes):
                raise DataNotInBytesException

            if path:
                _prefix = path
            else:
                upload_date, _prefix = self._get_prefix(
                    domain_name, dataset_name, user, file_type, upload_date, file_name
                )

            if data_bytes:
                result = awshelper.put_object(self.bucket_name, _prefix, data_bytes)
            else:
                result = None

            if result:
                response = {"exitcode": 0, "message": "Successfully saved data to s3."}
                if full_reload:
                    result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(
                        bucket_name=self.bucket_name,
                        domain_name=domain_name,
                        dataset_name=dataset_name,
                        upload_date=upload_date,
                        path=path,
                        region=self.region,
                    )
                    if result:
                        self.send_success_file(
                            domain_name, dataset_name, user, file_type, prefix=_prefix
                        )
                    else:
                        raise Exception(
                            "Failed to upload _SUCCESS file to trigger reload. Please trigger from UI."
                        )

            elif result is False:
                response = {"exitcode": 1, "message": "Could not save data to s3."}
            else:
                response = {"exitcode": 0, "message": "No data to write."}
        except Exception as ex:
            response = {"exitcode": 1, "message": ex}
        return response
