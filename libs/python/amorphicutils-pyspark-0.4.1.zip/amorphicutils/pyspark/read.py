"""
Read using pyspark
=================
Defines class Read, which is used to read data from amorphic datalake backed by s3.
"""

import boto3
import pyspark

from typing import Optional, Union, List, Dict

try:
    from awsglue.context import GlueContext
except ImportError:
    pass


import amorphicutils.awshelper
# import amorphicutils.interface
from amorphicutils.amorphiclogging import Log4j


class DwhRead:
    """
    Class to read data from Datawarehouse(Redshift/Aurora)
    """

    def __init__(
        self, dwh_type, dwh_host, dwh_port, dwh_db, dwh_user, dwh_pass, tmp_dir
    ):
        """
        Initialize class with required parameters for connecting to data warehouse.

        :param dwh_type: Is it "redshift" or "aurora"
        :param dwh_host:  Hostname for DWH
        :param dwh_port: Port for DWH
        :param dwh_db: Database name to connect. ex. cdap
        :param dwh_user: Username to use for connection
        :param dwh_pass: Password for the user
        :param tmp_dir:  Temp directory for store intermediate result
        """

        self.connection_options = {
            "url": "jdbc:redshift://{host}:{port}/{db}".format(
                host=dwh_host, port=dwh_port, db=dwh_db
            ),
            "user": dwh_user,
            "password": dwh_pass,
            "redshiftTmpDir": tmp_dir,
        }

        self.dwh_type = dwh_type

    def read_from_redshift(self, glue_context, domain_name, dataset_name, **kwargs):
        """
        Return response with data from Redshift

        :param glue_context: GlueContext
        :param domain_name: Domain name of dataset
        :param dataset_name: Dataset name
        :param kwargs: Extra params like: hashfield
        :return:

        >>> dwh_reader = DwhRead("redshift", DWH_HOST, DWH_PORT, DWH_DB, dwh_user, dwh_pass, tmp_dir)
        >>> response = dwh_reader.read_from_redshift(glue_context, domain_name, dataset_name)
        """
        try:
            table = ".".join([domain_name, dataset_name])
            conn_details = self.connection_options.copy()
            conn_details["dbtable"] = table
            if "hashfield" in kwargs:
                conn_details["hashfield"] = kwargs["hashfield"]
            data = glue_context.create_dynamic_frame_from_options(
                "redshift", conn_details
            )
            response = {
                "exitcode": 0,
                "message": "Successfully loaded data from {dwh} into spark dataframe".format(
                    dwh=self.dwh_type
                ),
                "data": data,
            }

        except Exception as ex:
            response = {"exitcode": 1, "message": ex, "data": None}
        finally:
            del conn_details

        return response


# class SparkRead(interface.AmorphicReadWriteInterface):
class SparkRead:
    """
    Class to read using Spark Context
    """

    def __init__(self, bucket_name, spark, logger=None):
        """
        Initialize the class with dataset specific details

        :param bucket_name: name of the bucket (dlz)
        :param spark: SparkContext

        >>> reader = SparkRead(bucket_name, spark)
        """

        self.spark = spark
        self.bucket_name = bucket_name
        self._logger = Log4j(spark).get_logger() if not logger else logger

    def _get_s3_ds_path(self, domain_name, dataset_name):
        """
        returns the prefix for data to read
        :param domain_name:
        :param dataset_name:
        :return:
        """
        return "/".join(["s3:/", self.bucket_name, domain_name, dataset_name])

    def _get_prefix(self, domain_name, dataset_name, upload_date=None):
        """
        returns the prefix for data to read
        :param domain_name:
        :param dataset_name:
        :param upload_date:
        :return:
        """
        full_s3_path = self._get_s3_ds_path(domain_name, dataset_name) + "/"
        if not upload_date:
            _prefix = full_s3_path + "*/"
        else:
            _prefix = full_s3_path + "upload_date=" + str(upload_date) + "/"
        return _prefix

    def read_csv_data(
        self,
        domain_name,
        dataset_name,
        schema=None,
        header=False,
        delimiter=",",
        multline=True,
        upload_date=None,
        path=None,
        **kwargs,
    ):
        """
        Read csv data from s3 using spark read api and generate spark dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param schema: schema of the data.
        :type: StructType([StructField()])
        :param header: True if data files contains header. Default: False
        :param delimiter: delimiter in the dataset. Default: ","
        :param multline: Read data which may span multiple lines for column. Default: True
        :param upload_date: upload date timestamp. Ignored if full_load is True
        :param path: Path of the file Optional: If given then implicit prefix creation is ignored
        :param kwargs: Optional arguments available for pyspark read

        :return: spark dataframe of data from dataset

        >>> reader = Read("dlz_bucket", spark=spark_context)
        >>> df = reader.read_csv_data("testdomain", "testdataset")
        """

        try:
            self._logger.info(
                "In SparkRead.read_csv_data Reading csv data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)
            if schema:
                spark_df = (
                    self.spark.read.option("delimiter", delimiter)
                    .option("header", header)
                    .schema(schema)
                    .csv(_prefix, multiLine=multline, **kwargs)
                )
            else:
                spark_df = (
                    self.spark.read.option("delimiter", delimiter)
                    .option("header", header)
                    .csv(_prefix, multiLine=multline, **kwargs)
                )

            response = {
                "exitcode": 0,
                "message": "Successfully loaded s3 data into spark dataframe",
                "data": spark_df,
            }

        except Exception as ex:
            self._logger.error(
                "In SparkRead.read_csv_data Error occurred while reading csv data from "
                "dataset {0}.{1}. Error: {2}".format(domain_name, dataset_name, ex)
            )
            response = {"exitcode": 1, "message": ex, "data": None}
        return response

    def read_parquet(
        self,
        domain_name: str,
        dataset_name: str,
        upload_date: Optional[str] = None,
        path: Optional[str] = None,
        **kwargs: Dict[str, Union[str, int, float, bool, None]],
    ) -> Dict[str, Union[int, str, pyspark.sql.dataframe.DataFrame, None]]:
        """
        Read data from Parquet files and return a pandas DataFrame.

        :param domain_name: Domain name of the dataset.
        :param dataset_name: Dataset name.
        :param upload_date: Upload date timestamp.
        :param path: Path of the file to read from.
        :param kwargs: Optional arguments available for pandas DataFrame read.

        :return: A dictionary with the following keys:
            - "exitcode": Exit code (0 for success, 1 for failure).
            - "message": A message describing the result.
            - "data": spark dataframe of data from dataset (None if unsuccessful).
        :example:
                >>> amorphic_reader = Read(bucket_name="dlz_bucket")
                >>> result = amorphic_reader.read_parquet(domain_name="testdomain", dataset_name="testdataset")
        """
        try:
            self._logger.info(
                "In SparkRead.read_parquet Reading parquet data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)

            spark_df = self.spark.read.parquet(_prefix, **kwargs)

            response = {
                "exitcode": 0,
                "message": "Successfully loaded s3 data into spark dataframe",
                "data": spark_df,
            }
        except Exception as ex:
            self._logger.error(
                "In SparkRead.read_parquet Error occurred while reading parquet data from "
                "dataset {0}.{1}. Error: {2}".format(domain_name, dataset_name, ex)
            )
            response = {"exitcode": 1, "message": ex, "data": None}
        return response

    def read_json(
        self, domain_name, dataset_name, upload_date=None, path=None, **json_kwargs
    ):
        """
        Read json data from s3 using spark read api and generate spark dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param upload_date: upload date timestamp. Ignored if full_load is True
        :param path: Path of the file Optional: If given then implicit prefix creation is ignored
        :param json_kwargs: Optional arguments available for pyspark parquet read

        :return: spark dataframe of data from dataset

        >>> reader = Read("dlz_bucket", spark=spark_context)
        >>> df = reader.read_json("testdomain", "testdataset")
        """

        try:
            self._logger.info(
                "In SparkRead.read_json Reading json data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )

            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)

            spark_df = self.spark.read.json(_prefix, **json_kwargs)

            response = {
                "exitcode": 0,
                "message": "Successfully loaded s3 data into spark dataframe",
                "data": spark_df,
            }
        except Exception as ex:
            self._logger.error(
                "In SparkRead.read_json Error occurred while reading json data from "
                "dataset {0}.{1}. Error: {2}".format(domain_name, dataset_name, ex)
            )
            response = {"exitcode": 1, "message": ex, "data": None}
        return response

    def __read_excel(
        self,
        domain_name,
        dataset_name,
        schema=None,
        sheet_name=0,
        header=False,
        upload_date=None,
        path=None,
    ):
        """
        Read excel data from s3 using spark read api
        with com.crealytics.spark.excel package and generate spark dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param schema: schema of the data.
        :param sheet_name: sheet name or indices to read data from. Default: 0
        :type: StructType([StructField()])
        :param header: True if data files contains header. Default: False
        :param upload_date: upload date timestamp. Ignored if full_load is True
        :param path: Path of the file Optional: If given then implicit prefix creation is ignored
        :return: spark dataframe of data from dataset

        >>> reader = Read("dlz_bucket", spark=spark_context)
        >>> df = reader.read_excel("testdomain", "testdataset")
        """

        try:
            self._logger.info(
                "In SparkRead.read_excel Reading excel data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)
            if schema:
                spark_df = (
                    self.spark.read.format("com.crealytics.spark.excel")
                    .option("useHeader", "true" if header else "false")
                    .option("sheetName", sheet_name)
                    .schema(schema)
                    .load(_prefix)
                )
            else:
                spark_df = (
                    self.spark.read.format("com.crealytics.spark.excel")
                    .option("useHeader", "true" if header else "false")
                    .option("sheetName", sheet_name)
                    .load(_prefix)
                )

            response = {
                "exitcode": 0,
                "message": "Successfully loaded s3 data into spark dataframe",
                "data": spark_df,
            }

        except Exception as ex:
            self._logger.error(
                "In SparkRead.read_csv_data Error occurred while reading csv data from "
                "dataset {0}.{1}. Error: {2}".format(domain_name, dataset_name, ex)
            )

        return response

    def __read_avro_data(
        self, domain_name, dataset_name, schema=None, upload_date=None, path=None
    ):
        """
        Read avro data from s3 using spark read api and generate spark dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param schema: schema of the data.
        :type: StructType([StructField()])
        :param upload_date: upload date timestamp. Ignored if full_load is True
        :param path: Path of the file Optional: If given then implicit prefix creation is ignored
        :return:
        """

        try:
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)

            if schema:
                spark_df = self.spark.read.format("avro").load(_prefix)
            else:
                spark_df = self.spark.read.format("avro").load(_prefix)

            response = {
                "exitcode": 0,
                "message": "Successfully loaded s3 avro data into spark dataframe",
                "data": spark_df,
            }

        except Exception as ex:
            response = {"exitcode": 1, "message": ex, "data": None}
        return response


class GlueRead:
    """
    Class to read using Glue Context
    """

    def __init__(self, bucket_name, glue_context, logger=None):
        """
        Initialize the class with dataset specific details

        :param bucket_name: name of the bucket (dlz)
        :param glue_context: SparkContext

        >>> reader = GlueRead(bucket_name, glue_context)
        """

        self.glue_context = glue_context
        self.bucket_name = bucket_name
        self._logger = (
            Log4j(glue_context.spark_session).get_logger() if not logger else logger
        )

    def _get_prefix(self, domain_name, dataset_name, upload_date=None):
        """
        returns the prefix for data to read
        :param domain_name:
        :param dataset_name:
        :param upload_date:
        :return:
        """

        full_s3_path = "/".join(
            ["s3:/", self.bucket_name, domain_name, dataset_name, ""]
        )
        if not upload_date:
            _prefix = full_s3_path + "*/"
        else:
            _prefix = full_s3_path + "upload_date=" + str(upload_date) + "/"
        return _prefix

    def read_csv_data(
        self,
        domain_name,
        dataset_name,
        schema=None,
        header=False,
        delimiter=",",
        multiline=True,
        upload_date=None,
        path=None,
        **kwargs,
    ):
        """
        Read csv data from s3 using spark read api and generate spark dataframe

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :param schema: schema of the data.
        :type: StructType([StructField()])
        :param header: True if data files contains header. Default: False
        :param delimiter: delimiter in the dataset. Default: ","
        :param multiline: Read data which may span multiple lines for column. Default: True
        :param upload_date: upload date timestamp. Ignored if full_load is True
        :param path: Path of the file Optional: If given then implicit prefix creation is ignored
        :param kwargs: Optional arguments available for pyspark read

        :return: spark dataframe of data from dataset

        >>> reader = Read("dlz_bucket", spark=spark_context)
        >>> df = reader.read_csv_data("testdomain", "testdataset")
        """

        try:
            self._logger.info(
                "In GlueRead.read_csv_data Reading csv data from dataset {0}.{1}.".format(
                    domain_name, dataset_name
                )
            )
            if path:
                _prefix = path
            else:
                _prefix = self._get_prefix(domain_name, dataset_name, upload_date)

            dynamic_df = self.glue_context.create_dynamic_frame_from_options(
                connection_type="s3",
                connection_options={
                    "paths": [_prefix],
                    "groupFiles": "inPartition",
                    "groupSize": "268435456",
                    "recurse": True,
                },
                format="csv",
                format_options={
                    "withHeader": header,
                    "separator": delimiter,
                    "multiLine": multiline,
                    **kwargs,
                },
                transformation_ctx="glue_df",
            )

            spark_df = dynamic_df.toDF()

            if schema:
                # Apply schema
                spark_df = self.glue_context.spark_session.createDataFrame(
                    spark_df.rdd, schema=schema
                )

            response = {
                "exitcode": 0,
                "message": "Successfully loaded s3 data into spark dataframe",
                "data": spark_df,
            }

        except Exception as ex:
            self._logger.error(
                "In GlueRead.read_csv_data Error occurred while reading csv data from "
                "dataset {0}.{1}. Error: {2}".format(domain_name, dataset_name, ex)
            )
            response = {"exitcode": 1, "message": ex, "data": None}
        return response


class Read:
    """
    Class to read data from Amorphic
    """

    def __init__(self, bucket_name, spark, region=None, logger=None):
        """
        Initialize the class with dataset specific details

        :param bucket_name: name of the bucket (dlz)
        :param spark: SparkContext

        >>> reader = Read("dlz_bucket", spark_context)
        """
        if region:
            self.s3_resource = boto3.resource("s3", region)
        else:
            self.s3_resource = boto3.resource("s3")
        self.region = region
        self.bucket = self.s3_resource.Bucket(bucket_name)
        self.bucket_name = bucket_name
        if isinstance(spark, GlueContext):
            self.instance = GlueRead(bucket_name, spark, logger=logger)
        else:
            self.instance = SparkRead(bucket_name, spark, logger=logger)

    def __getattr__(self, name):
        return self.instance.__getattribute__(name)

    def list_object(self, domain_name, dataset_name):
        """
        List the objects for specific datasets

        :param domain_name: domain name of the dataset
        :param dataset_name: dataset name
        :return: list of objects from s3

        >>> reader = Read("dlz_bucket", spark=spark_context)
        >>> reader.list_object("testdomain", "testdataset")
        """
        _prefix = domain_name + "/" + dataset_name + "/"
        return amorphicutils.awshelper.list_bucket_objects(
            self.bucket_name, _prefix, self.region
        )
