"""
Module to get spark from GlueContext
"""

import sys

try:
    from pyspark.context import SparkContext
except ImportError:
    print("failed to import pyspark")

try:
    from awsglue.utils import getResolvedOptions, GlueArgumentError
    from awsglue.context import GlueContext
    from awsglue.job import Job
except ImportError:
    print("failed to import awsglue")


class GlueSpark:
    """
    Class to get instance of spark session from aws glue
    """

    def __init__(self, job_name=None):
        """
        Initialize the class

        >>> glue_spark = GlueSpark(job_name="job_name")
        """
        # pylint: disable=invalid-name
        self.sc = SparkContext.getOrCreate()
        self.glue_context = GlueContext(self.sc)
        self.spark = self.glue_context.spark_session
        self.job = Job(self.glue_context)

        if not job_name:
            try:
                args = getResolvedOptions(sys.argv, ["JOB_NAME"])
                job_name = args.get("JOB_NAME", "AmorphicGlueApp")
            except Exception as e:
                job_name = "amorphic-default-job"
        args = getResolvedOptions(sys.argv, [])
        self.job.init(job_name, args)

    def get_spark(self, timezone=None):
        """
        Returns the spark session instance

        param timezone: Timezone value
        :return: SparkSession

        >>> glue_spark = GlueSpark(job_name="job_name")
        >>> spark = glue_spark.get_spark()
        """

        if timezone:
            self.spark.conf.set("spark.sql.session.timeZone", timezone)
        return self.spark

    def get_glue_context(self):
        """
        Return glue context instance
        :return: GlueContext

        >>> glue_spark = GlueSpark(job_name="job_name")
        >>> glue_context = glue_spark.get_glue_context()()
        """
        return self.glue_context

    def get_logger(self):
        """
        Return logger instance for glue
        :return: logger

        >>> glue_spark = GlueSpark(job_name="job_name")
        >>> logger = glue_spark.get_logger()()
        """
        return self.glue_context.get_logger()

    def commit_job(self):
        """
        Commit the glue job
        :return:
        """
        self.job.commit()
