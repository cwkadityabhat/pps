"""
Utility to interact with Data Warehouse
"""

import pg8000
import mysql.connector as mysql
from amorphicutils.amorphiclogging import Log4j

LOGGER = Log4j().get_logger()

# pylint: disable=broad-except, unexpected-keyword-arg


class InvalidDatawarehouseType(ValueError):
    """raise when datawarehouse is invalid"""


class DwhUtil:
    """
    Class to interact with datawarehouse(aurora or redshift)
    """

    def __init__(self, dwh_type, host, db, user, passwd, port):
        """
        Initialize the datawarehouse util

        :param dwh_type: "aurora" or "redshift"
        :param host: host of the datawarehouse instanfe
        :param db: database in datawarehouse to connect
        :param user: user id for datawarehouse authentication
        :param passwd: user password for datawarehouse authentication
        :param port: port of the datawarehouse

        >>> r_util = dwhutil.DwhUtil(dwh_type="aurora",
                                     user="testuser",
                                     passwd="user_password",
                                     host="dwh_host.internal.com",
                                     db="test_database",
                                     port=5439)
        """
        if dwh_type.lower() == "redshift":
            try:
                self.dwh_conn = pg8000.connect(
                    host=host,
                    database=db,
                    user=user,
                    password=passwd,
                    port=port,
                    ssl=True,
                )

                self.dwh_cur = self.dwh_conn.cursor()
            except Exception as ex:
                LOGGER.error("Unable to create connection with error %s", ex)
        elif dwh_type.lower() == "aurora":
            try:
                self.dwh_conn = mysql.connect(
                    host=host, database=db, user=user, password=passwd, port=port
                )

                self.dwh_cur = self.dwh_conn.cursor()
            except Exception as ex:
                LOGGER.error("Unable to create connection with error %s", ex)
        else:
            raise InvalidDatawarehouseType

    def __del__(self):
        self.dwh_cur.close()
        self.dwh_conn.close()

    def run_query(self, query):
        """
        Run the query on datawarehouse

        :param query: query to be executed
        :return:

        >>> r_util.run_query("SELECT MAX(age) FROM school_info_table;")
        """
        try:
            self.dwh_cur.execute(operation=query)
        except Exception as ex:
            LOGGER.error("Unable to execute the query with error %s", ex)

    def fetch_all(self):
        """
        Fetch all results from executed query

        :return:

        >>> data = r_util.fetch_all()
        """
        try:
            return self.dwh_cur.fetchall()
        except Exception as ex:
            LOGGER.error("Unable to fetch the data with error %s", ex)

    def fetch_one(self):
        """
        Fetch one row of the result from the executed query

        :return:

        >>> one_data = r_util.fetch_one()
        """
        try:
            return self.dwh_cur.fetchone()
        except Exception as ex:
            LOGGER.error("Unable to fetch the data with error %s", ex)
