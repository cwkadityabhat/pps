"""
Notification using python
=================
Defines class Notification, which is used to send notification.
"""

import smtplib
import boto3

import datetime
from email.message import EmailMessage
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.common import read_param_store

LOGGER = Log4j().get_logger()


class Notification:
    """
    Class to send notification.
    """

    def __init__(
        self, username, param_key, port, server=None, secure=True, region_name=None
    ):
        """
        Initialize the class with email server details

        :param username
        :param password
        :param port: server port
        :param server: Email server name
        :param secure: True represents secure string in parameters store, otherwise False
        :region: Region of your aws account to retrieve ssm parameters


        >>> notification = Notification("username", "password", "port", region_name="region_name")
        """
        if server:
            self.server = smtplib.SMTP_SSL(server, port)
        else:
            self.server = smtplib.SMTP_SSL("smtp.gmail.com", port)
        self.username = username
        param_value_response = read_param_store(
            param_key, secure, region_name=region_name
        )
        if param_value_response["exitcode"] == 1:
            LOGGER.error(
                "Failed to get value for parameter {} with error {}.".format(
                    param_key, param_value_response["message"]
                )
            )
            raise Exception(
                "Failed to get value for parameter {} with error {}.".format(
                    param_key, param_value_response["message"]
                )
            )
        else:
            self.password = param_value_response["data"]

    def build_email_body(self, content):
        """
        Build Email Body

        :param content
        """
        LOGGER.info("In Notification.build_email_body Email body generated")
        return """\
            <html>
            <br>
            Hello User,
            <p style="color:silver">{}</p>
            <br>
            <hr style="color:silver">
            <center style="color:silver"><i>Notification triggered at {} UTC.</i></center>
            <hr style="color:silver">
            <center><b>The Amorphic Data Team</b></center>
            <center style="color:silver">Powering AWS Data Lake Analytics
            <br>
            © Amorphic Data. All rights reserved.</center>
            </html>""".format(
            content, datetime.datetime.now(datetime.timezone.utc)
        )

    def send_email(self, sender, recipients_to, recipients_cc, subject, content):
        """
        send email notification

        :param sender
        :param recipients_to : list of email ids ['Jane.Mark@example.com', 'James.Steve@example.com']
        :param recipients_cc : list of email ids ['Jane.Mark@example.com', 'James.Steve@example.com']
        :param subject
        :param content

        >>> notification = Notification("server", "username", "password", region_name="region_name")
        >>> notification.send_email("sender", "recipients_to", "recipients_cc", subject", "content")
        """

        try:
            LOGGER.info("In Notification.send_email Sending email notification")
            msg = EmailMessage()
            msg["From"] = sender
            msg["To"] = ", ".join(recipients_to)
            msg["Cc"] = ", ".join(recipients_cc)
            msg["subject"] = subject
            mail_body = self.build_email_body(content)
            # msg.set_content(content)
            msg.add_alternative(mail_body, subtype="html")
            self.server.login(self.username, self.password)
            self.server.send_message(msg)
            self.server.quit()
            response = {"exitcode": 0, "message": "Email sent Successfully"}
            LOGGER.info("In Notification.send_email Email sent Successfully")
        except Exception as ex:
            LOGGER.error("Failed to sent Email with error: {}".format(ex))
            response = {
                "exitcode": 1,
                "message": "Failed to sent Email with error: {}".format(ex),
            }
        return response
