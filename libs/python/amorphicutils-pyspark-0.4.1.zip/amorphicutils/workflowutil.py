"""
Contain functions to integrate with Amorphic Workflows.
"""

import sys
import boto3
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from botocore.exceptions import ClientError
from pyspark.context import SparkContext
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.common import format_response

LOGGER = Log4j().get_logger()


def get_workflow_params():
    """
    Function to get the workflow execution parameters

    :param exitcode: 0 for success and 1 for failure
    :param message: Message for the outcome
    :param data: Data of the response

    :return: workflow_params
    """
    try:
        glue_client = boto3.client("glue")
        args = getResolvedOptions(
            sys.argv, ["JOB_NAME", "WORKFLOW_NAME", "WORKFLOW_RUN_ID"]
        )
        workflow_name = args["WORKFLOW_NAME"]
        workflow_run_id = args["WORKFLOW_RUN_ID"]
        workflow_params = glue_client.get_workflow_run_properties(
            Name=workflow_name, RunId=workflow_run_id
        )["RunProperties"]
        _response = format_response(
            0, "Successfully retrieved workflow execution params", workflow_params
        )
    except ClientError as cli_err:
        err_msg = "Exception raised in function get_workflow_params : " + str(cli_err)
        LOGGER.error(err_msg)
        _response = format_response(1, err_msg, None)
    return _response


def update_workflow_params(param_name, value):
    """
    Function to update the workflow execution parameters

    :param param_name: Name (key) of the parameter to be updated
    :param value:  New Value to be set for the param_name

    :return: status
    """
    try:
        glue_client = boto3.client("glue")
        args = getResolvedOptions(
            sys.argv, ["JOB_NAME", "WORKFLOW_NAME", "WORKFLOW_RUN_ID"]
        )
        workflow_name = args["WORKFLOW_NAME"]
        workflow_run_id = args["WORKFLOW_RUN_ID"]
        workflow_params = glue_client.get_workflow_run_properties(
            Name=workflow_name, RunId=workflow_run_id
        )["RunProperties"]

        workflow_params[param_name] = value
        glue_client.put_workflow_run_properties(
            Name=workflow_name, RunId=workflow_run_id, RunProperties=workflow_params
        )
        _response = format_response(0, "Successfully updated execution parameter", None)
    except ClientError as cli_err:
        err_msg = "Exception raised in function update_workflow_params : " + str(
            cli_err
        )
        LOGGER.error(err_msg)
        _response = format_response(1, err_msg, None)
    return _response
