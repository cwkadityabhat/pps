"""
Contains version number for package
"""

# Version
__version__ = "0.4.1"
