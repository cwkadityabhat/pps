"""
Common utils to used for API development
"""

import json
import requests


def text_to_dict(text):
    """
    Convert text to dictionary

    :param text: text to be changed to dict
    :return: dict format of the text
    """
    try:
        result = json.loads(text)
    except Exception:
        result = None
    return result


def generate_json_reponse(response, exitcode=0, message=None):
    """
    Generate the json response for every API call

    :param response: Either request response or data to be send as response
    :param exitcode: 0 for success or other for failure
    :param message: Custom message for response
    :return: dict in format of {'exitcode': 0, 'message': 'custom message', 'data': payload}
    """

    try:
        if isinstance(response, requests.models.Response):
            if response.status_code == 200:
                custom_response = {
                    "exitcode": 0,
                    "message": "Successfully retrieved data from url: {url}".format(url=response.url),
                    "data": json.loads(response.text),
                    "response": response
                }
            else:
                custom_response = {
                    "exitcode": response.status_code,
                    "message": "Failed to query url {url} with error {error}".format(
                        url=response.url, error=response.reason),
                    "data": json.loads(response.text),
                    "response": response
                }
        else:
            custom_response = {
                "exitcode": exitcode,
                "message": message,
                "data": response
            }
    except Exception as ex:
        custom_response = {
            "exitcode": 1,
            "message": "Failed to generate response with error {error}".format(error=ex),
            "data": None
        }

    return custom_response
