"""
Class for Job
"""

import json
import os
import re
import time
import requests

from amorphicutils.api.utils import generate_json_reponse, text_to_dict
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.api.api_common import ApiCommon

# pylint: disable=missing-function-docstring,invalid-name,unused-argument


class Jobs(ApiCommon):
    """
    Class to call etl job related api
    """

    def __init__(self, api_wrapper):
        ApiCommon.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()

        self.jobs_param_validation_functions = {
            'JobName': lambda x: bool(x and isinstance(x, str)),
            'ETLJobType': lambda x: x in ['pythonshell', 'spark'],
            'ParameterAccess': lambda x: bool(x and isinstance(x, list)) or bool(not x),
            'ScriptPath': lambda x: bool(x and os.path.exists(x)) or bool(not x),
            'DefaultArguments': lambda x: bool(x and isinstance(x, dict)) or bool(not x),
            'Description': lambda x: bool(x and isinstance(x, str)),
            'PythonVersion': lambda x: str(x) in ["2", "3"],
            'NetworkConfiguration': lambda x: x in ['general-public-network',
                                                    'app-public-network',
                                                    'app-private-network'],
            'WorkerType': lambda x: x in ['G.1X', 'G.2X', 'Standard', None]
        }

        self.python_libs_compatibility = {
            'pythonshell': ['egg', 'whl', 'py'],
            'spark': ['zip', 'py']
        }

    def _get_common_libs_id_list(self, shared_libs):
        # Create shared libs list
        common_libs_id_list = []
        if shared_libs:
            if not isinstance(shared_libs, list):
                shared_libs = [shared_libs]
            for lib_name in shared_libs:
                lib_details_reponse = self.get_common_libs(LibraryName=lib_name)
                if lib_details_reponse['exitcode'] == 0:
                    lib_id = lib_details_reponse['data']['LibraryId']
                    common_libs_id_list.append(lib_id)
                else:
                    self._logger.error("In {f_name}, Failed to get details for common lib {name}.".format(
                        f_name=__name__, name=lib_name))
                    raise Exception(lib_details_reponse['message'])
        return common_libs_id_list

    @staticmethod
    def _validate_dataset_access_dict(dataset_access):
        """
        Validates the dataset access list and return the list in required format

        :param dataset_access:
        :return:
        """

        if not all(k in dataset_access for k in ("Owner", "ReadOnly")):
            raise ValueError("DatasetAccess should be in format "
                             "{'Owner':[{'DatasetName': '<name>', 'DatasetId': '<id>'}], "
                             "'ReadOnly':[{'DatasetName': '<name>', 'DatasetId': '<id>'}]}")

        final_dataset_list = {
            'Owner': [],
            'ReadOnly': []
        }
        failed_dataset_list = {
            'Owner': [],
            'ReadOnly': []
        }
        for dataset_type, dataset_list in dataset_access.items():
            for dataset in dataset_list:
                if 'DatasetName' not in dataset or 'DatasetId' not in dataset:
                    failed_dataset_list[dataset_type].append(dataset)
                else:
                    final_dataset_list[dataset_type].append(
                        {
                            'DatasetName': dataset['DatasetName'],
                            'DatasetId': dataset['DatasetId']
                        }
                    )

        if failed_dataset_list['Owner'] or failed_dataset_list['ReadOnly']:
            raise Exception("Validation failed for {failed_elem}".format(failed_elem=failed_dataset_list))
        return final_dataset_list

    def _get_job_id_type(self, JobName):
        """
        Returns the job id of a job

        :param JobName: Name of the job
        :return:
        """

        job_details = self.get_job(JobName=JobName)
        if job_details['exitcode'] == 0:
            job_id = job_details['data']['Id']
            return {
                'job_id': job_id,
                'type': job_details['data']['ETLJobType'],
                'external_python_libs': job_details['data']['DefaultArguments'].get('--extra-py-files'),
                'job_s3_dir': '/'.join(job_details['data']['ScriptLocation'].split('/')[0:-2])
            }

        return job_details

    @staticmethod
    def _upload_with_presigned_url(presigned_url, file):
        """
        Uploads a file to presigned url

        :param presigned_url: s3 presigned url
        :param file: file location

        :return:
        """

        try:
            f = open(file, 'rb')
            data = f.read()
            upload_response = requests.put(presigned_url, data=data, verify=True)
            if upload_response.status_code != 200:
                raise Exception(upload_response.text)
        except Exception as ex:
            response = generate_json_reponse(None, exitcode=1, message="Failed to upload with error {err}.".
                                             format(err=str(ex)))
        else:
            response = generate_json_reponse(None, exitcode=0, message="Uploaded the data.")
        finally:
            f.close()
            del data
        return response

    # pylint: disable=too-many-branches
    def _get_jobs_payload(self, arguments):

        if 'Description' in arguments:
            if not arguments['Description']:
                arguments['Description'] = "Created using Amorphicutils."
            else:
                # Python 2: Convert unicode to string
                arguments['Description'] = str(arguments['Description'])

        # Validate the arguments
        for k, validation_func in self.jobs_param_validation_functions.items():
            if not validation_func(arguments[k]):
                raise ValueError("Failed to validate value for key: {key} for value: {value}".format(
                    key=k, value=arguments[k]))

        if arguments['DatasetAccess']:
            arguments['DatasetAccess'] = self._validate_dataset_access_dict(arguments['DatasetAccess'])
        else:
            arguments['DatasetAccess'] = {
                'Owner': [],
                'ReadOnly': []
            }

        payload = {
            'JobName': arguments['JobName'],
            'Description': arguments['Description'],
            'ETLJobType': arguments['ETLJobType'],
            'NetworkConfiguration': arguments['NetworkConfiguration'],
            'MaxRetries': arguments['MaxRetries'],
            "DatasetAccess": arguments['DatasetAccess'],
            "JobBookmarkOption": arguments['JobBookmarkOption'],
            "IsAutoScalingEnabled": arguments['IsAutoScalingEnabled']
        }

        if arguments['Keywords']:
            payload['Keywords'] = arguments['Keywords']
        else:
            payload['Keywords'] = [arguments['JobName']]
        if arguments['Timeout']:
            payload['Timeout'] = arguments['Timeout']
        if arguments['MaxConcurrentRuns']:
            payload['MaxConcurrentRuns'] = arguments['MaxConcurrentRuns']
        if arguments['DefaultArguments']:
            payload['DefaultArguments'] = arguments['DefaultArguments']
        # Add Parameter Access
        if arguments['ParameterAccess']:
            payload['ParameterAccess'] = arguments['ParameterAccess']

        # Validate python and glue compatibility
        if str(arguments['GlueVersion']) == "0.9" and str(arguments['PythonVersion']) == "3":
            raise ValueError("Glue version 0.9 is not compatible with Python version 3. Please use Glue 1.0 version.")

        payload['GlueVersion'] = str(arguments['GlueVersion'])
        payload['PythonVersion'] = str(arguments['PythonVersion'])

        # Validate pythonshell and glue allocation capacity
        if arguments['ETLJobType'] == "pythonshell":
            if arguments['AllocatedCapacity'] and arguments['AllocatedCapacity'] not in [0.0625, 1]:
                raise ValueError("Valid allocated_capacity for ETLJobType python is 0.0625 or 1.")

            payload["AllocatedCapacity"] = arguments['AllocatedCapacity']
        elif arguments['ETLJobType'] == "spark":
            if arguments['WorkerType'] and not arguments['NumberOfWorkers']:
                raise Exception("Both WorkerType and num_workers should be passed.")
            if arguments['WorkerType'] and arguments['NumberOfWorkers']:
                if arguments['NumberOfWorkers'] < 2:
                    raise ValueError("Number of worker should be greater than 1.")
                payload["WorkerType"] = arguments['WorkerType']
                payload["NumberOfWorkers"] = arguments['NumberOfWorkers']
            elif arguments['AllocatedCapacity']:
                if arguments['AllocatedCapacity'] < 2:
                    raise ValueError("Allocated capacity should be greater than 1.")
                payload["AllocatedCapacity"] = arguments['AllocatedCapacity']
            else:
                payload["AllocatedCapacity"] = 2

        if arguments['kwargs']:
            self._logger.warning("In {f_name}, following arguments {args} are not defined in function "
                                 "and thus not used under payload.".format(
                                     f_name=__name__, args=arguments['kwargs']))

        return payload

    # pylint: disable=too-many-locals,too-many-arguments
    def create_job(self, JobName, ETLJobType, ScriptPath, Description=None, PythonVersion="3",
                   GlueVersion="1.0", AllocatedCapacity=None, WorkerType=None, NumberOfWorkers=None, Keywords=None,
                   NetworkConfiguration='general-public-network', MaxRetries=1, Timeout=None, MaxConcurrentRuns=None,
                   DatasetAccess=None, SharedLibraries=None, ParameterAccess=None, DefaultArguments=None,
                   JobBookmarkOption='disable', IsAutoScalingEnabled=False, **kwargs):
        """
        Create ETL job in Amorphic

        :param JobName: Name of the job
        :param ETLJobType: Type of the job, can be one from ['pythonshell', 'spark']
        :param ScriptPath: Local path of the main script
        :param Description: Description of the job
        :param PythonVersion: Python version for the job, can be 2 or 3, Default: 3
        :param GlueVersion: Version of the Glue, can be 0.9 or 1, Default: 1
        :param AllocatedCapacity: Allocated Capacity for job based on job type.
          * pythonshell: Can be 0.0625 or 1
          * spark: greater than 2
        :param WorkerType: WorkerType for special workload,  ['G.1X', 'G.2X', 'Standard', None], Default:None
        :param NumberOfWorkers: Number of Workers must be greater than 2, Default:None
        :param Keywords: Keywords for the job
        :param NetworkConfiguration: Network configuration for the job,
            can be one from ['general-public-network', 'app-public-network', 'app-private-network'],
            Default: general-public-network
        :param MaxRetries: Maximum retries by job, Default: 1
        :param Timeout: Timeout for the job
        :param MaxConcurrentRuns: Maximum concurrent run of the job
        :param DatasetAccess: Dataset access to the job. Format must be,

            { 'Owner': list({ 'DatasetName': '<DatasetName>', 'DatasetId': '<DatasetId>' }),
            'ReadOnly': list({ 'DatasetName': '<DatasetName>', 'DatasetId': '<DatasetId>' }) }

        :param SharedLibraries: Name of the shared libraries
        :param DefaultArguments: Arguments for job in dictionary format
        :param ParameterAccess: List of ParameterAccess
        :param JobBookmarkOption: enable or disable
        :param IsAutoScalingEnabled: True or False, Default: False
        :param kwargs: Extra arguments
        :return:
        """

        self._logger.info("In {f_name}, creating job with name {job_name}.".format(
            f_name=__name__, job_name=JobName
        ))

        _path = "jobs"

        arguments = locals()

        payload = self._get_jobs_payload(arguments=arguments)

        # Create shared libs list
        common_libs_id_list = self._get_common_libs_id_list(arguments['SharedLibraries'])
        payload['SharedLibraries'] = common_libs_id_list

        headers = {'Content-Type': 'text/plain'}
        job_creation_response = self.api_wrapper.make_request(_path, method='post',
                                                              headers=headers, data=json.dumps(payload),
                                                              verify=True)

        response = generate_json_reponse(job_creation_response)

        # Upload script
        if response['exitcode'] == 0:
            job_id = response['data']['JobId']
            try:
                upload_script_resp = self.update_script(JobName=JobName,
                                                        ScriptPath=ScriptPath,
                                                        JobId=job_id)

                if upload_script_resp['exitcode'] == 0:
                    _path = "job_path"

                    publish_job_response = self.api_wrapper.make_request(_path, fields=job_id, method='put',
                                                                         verify=True, publish='true')
                    response = generate_json_reponse(publish_job_response)
                else:
                    response = upload_script_resp

                if response['exitcode'] != 0:
                    raise Exception("Failed to publish job with error {err}.".format(err=response['message']))
            except Exception as ex:
                # Delete job
                self.delete_job(JobName=JobName, JobId=job_id)
                response = generate_json_reponse(None, exitcode=1, message="Failed to publish job with error {err}."
                                                 .format(err=str(ex)))

        return response

    def delete_job(self, JobName=None, JobId=None):
        """
        Deletes ETL job by Id or Name

        :param JobName: ETL job name
        :param JobId: ETL job id
        :return:
        """

        if not (JobName or JobId):
            self._logger.error("In {f_name}, either JobName or JobId must be passed.".format(f_name=__name__))
            raise Exception("Either JobName or JobId must be passed.")

        self._logger.info("In {f_name}, deleting job with name {job_name} and id {job_id}.".format(
            f_name=__name__, job_name=JobName, job_id=JobId
        ))

        _path = "job_path"

        if not JobId:
            job_details = self._get_job_id_type(JobName=JobName)
            if 'exitcode' not in job_details:
                JobId = job_details['job_id']
            else:
                return job_details

        if JobId:
            # Empty the extra resource
            self.update_extra_resource(JobId=JobId)
            # Sleep as process is asynchronous
            time.sleep(3)

            job_deletion_response = self.api_wrapper.make_request(_path, fields=JobId, method='delete',
                                                                  headers=None, data=None, verify=True)
            response = generate_json_reponse(job_deletion_response)
        else:
            response = generate_json_reponse(None, exitcode=1, message="No job found with job id {id}.".format(
                id=JobId
            ))
        return response

    # pylint disable: too-many-arguments
    def update_job(self, JobName, ScriptPath=None, Description=None,
                   PythonVersion=None, GlueVersion=None, AllocatedCapacity=None, WorkerType=None, NumberOfWorkers=None,
                   Keywords=None, NetworkConfiguration=None, MaxRetries=None, Timeout=None,
                   MaxConcurrentRuns=None, DatasetAccess=None, SharedLibraries=None, DefaultArguments=None,
                   ParameterAccess=None, JobBookmarkOption='disable', IsAutoScalingEnabled=False, **kwargs):

        """
        Create ETL job in Amorphic

        :param JobName: Name of the job
        :param ScriptPath: Local path of the main script
        :param Description: Description of the job
        :param PythonVersion: Python version for the job, can be 2 or 3, Default: 3
        :param GlueVersion: Version of the Glue, can be 0.9 or 1, Default: 1
        :param AllocatedCapacity: Allocated Capacity for job based on job type.
          * pythonshell: Can be 0.0625 or 1
          * spark: greater than 2
        :param WorkerType: WorkerType for special workload,  ['G.1X', 'G.2X', 'Standard', None], Default:None
        :param NumberOfWorkers: Number of Workers must be greater than 2, Default:None
        :param Keywords: Keywords for the job
        :param NetworkConfiguration: Network configuration for the job,
            can be one from ['general-public-network', 'app-public-network', 'app-private-network'],
            Default: general-public-network
        :param MaxRetries: Maximum retries by job, Default: 1
        :param Timeout: Timeout for the job
        :param MaxConcurrentRuns: Maximum concurrent run of the job
        :param DatasetAccess: Dataset access to the job. Format must be,

            { 'Owner': list({ 'DatasetName': '<DatasetName>', 'DatasetId': '<DatasetId>' }),
            'ReadOnly': list({ 'DatasetName': '<DatasetName>', 'DatasetId': '<DatasetId>' }) }

        :param SharedLibraries: Name of the shared libraries
        :param DefaultArguments: Arguments for job in dictionary format
        :param ParameterAccess: List of ParameterAccess
        :param JobBookmarkOption: enable or disable
        :param IsAutoScalingEnabled: True or False, Default: False
        :param kwargs: Extra arguments
        :return:
        """

        self._logger.info("In {f_name}, updating job with name {job_name}.".format(
            f_name=__name__, job_name=JobName
        ))

        _path = 'job_path'
        job_details_response = self.get_job(JobName=JobName)
        if job_details_response['exitcode'] == 0:
            arguments = locals()

            # Add DefaultArguments

            existing_default_args = job_details_response['data']['DefaultArguments']

            if not arguments['DefaultArguments']:
                arguments['DefaultArguments'] = existing_default_args
            else:
                if not self.jobs_param_validation_functions['DefaultArguments'](arguments['DefaultArguments']):
                    raise ValueError('DefaultArguments must be of dict type.')
                existing_default_args.update(arguments['DefaultArguments'])
                arguments['DefaultArguments'] = existing_default_args

            # Update arguments with existing values if empty and validate
            for key, value in arguments.items():
                if key in job_details_response['data'].keys() and value is None:
                    arguments[key] = job_details_response['data'][key]

            job_id = job_details_response['data']['Id']
            arguments['ETLJobType'] = job_details_response['data']['ETLJobType']

            payload = self._get_jobs_payload(arguments)

            # Create shared libs list
            existing_libs_set = set(job_details_response['data']['SharedLibraries']) \
                if 'SharedLibraries' in job_details_response['data'] else set()
            common_libs_id_set = self._get_common_libs_id_list(arguments['SharedLibraries'])
            payload['SharedLibraries'] = list(existing_libs_set.union(common_libs_id_set))

            immutable_variable = ['JobName', 'ETLJobType']
            update_payload = {key: value for key, value in payload.items() if key not in immutable_variable}
            job_update_reponse = self.api_wrapper.make_request(_path,
                                                               method='put',
                                                               fields=job_id,
                                                               data=json.dumps(update_payload))
            response = generate_json_reponse(job_update_reponse)
            # Upload script
            if response['exitcode'] == 0 and ScriptPath:
                upload_script_resp = self.update_script(JobName=JobName,
                                                        ScriptPath=ScriptPath,
                                                        JobId=job_id)

                if upload_script_resp['exitcode'] != 0:
                    response = generate_json_reponse(None,
                                                     exitcode=1,
                                                     message="Failed to update script for job with error {err}."
                                                     .format(err=str(upload_script_resp['message'])))
                else:
                    response = generate_json_reponse(None,
                                                     exitcode=0,
                                                     message="Successfully update job and script.")

        else:
            response = job_details_response
        return response

    def update_script(self, ScriptPath, JobName=None, JobId=None):
        """
        Updates the ETL script

        :param ScriptPath: local script path
        :param JobName: ETL job name
        :param JobId: ETL job id

        :return:
        """

        if not(JobName or JobId):
            self._logger.error("In {f_name}, either JobName or JobId must be passed.".format(f_name=__name__))
            raise Exception("Either JobName or JobId must be passed.")

        self._logger.info("In {f_name}, updating script for job with name {job_name}.".format(
            f_name=__name__, job_name=JobName
        ))

        _path = 'job_script_path'

        if not os.path.exists(ScriptPath):
            raise Exception("Script file {file} doesn't exists.".format(file=ScriptPath))

        if not JobId:
            job_details = self._get_job_id_type(JobName=JobName)
            if 'exitcode' not in job_details:
                JobId = job_details['job_id']
            else:
                return job_details

        if JobId:
            presigned_url_response = self.api_wrapper.make_request(_path, fields=JobId, method='post',
                                                                   verify=True)
            if presigned_url_response.status_code == 200:
                presigned_url = text_to_dict(presigned_url_response.text)['Message']

                try:
                    f = open(ScriptPath, 'rb')
                    data = f.read()
                    upload_script_response = requests.put(presigned_url, data=data, verify=True)
                    if upload_script_response.status_code != 200:
                        raise Exception(upload_script_response.text)
                except Exception as ex:
                    response = generate_json_reponse(None,
                                                     exitcode=1,
                                                     message="Failed to upload script with error {err}.".
                                                     format(err=str(ex)))
                else:
                    response = generate_json_reponse(None, exitcode=0, message="Uploaded script")
                finally:
                    f.close()
                    del data
            else:
                response = generate_json_reponse(presigned_url_response)
        else:
            response = generate_json_reponse(None, exitcode=1, message="No job found with job id {id}.".format(
                id=JobId
            ))
        return response

    def get_job(self, JobName):
        """
        Returns job details

        :param JobName: ETL job name
        :return:
        """

        self._logger.info("In {f_name}, getting job with name {job_name}.".format(
            f_name=__name__, job_name=JobName
        ))

        resource_id_response = self.get_resource_id("jobs", resource_name=JobName)
        if resource_id_response['exitcode'] == 0:
            job_id = resource_id_response['data']['ResourceId']
            _operation = "job_path"
            job_details_response = self.api_wrapper.make_request(_operation, fields=job_id)
            response = generate_json_reponse(job_details_response)
        else:
            response = resource_id_response
            ### To be removed in future
            all_jobs_reponse = self.get_all_jobs()
            if all_jobs_reponse['exitcode'] == 0:
                all_jobs = all_jobs_reponse['data']['jobs']

                for job in all_jobs:
                    if JobName == job['JobName']:
                        response = generate_json_reponse(job, exitcode=0, message="Retrieved job details.")
                        return response
                response = generate_json_reponse(None,
                                                 exitcode=1,
                                                 message="No job found with name {name}.".format(name=JobName))
            else:
                response = all_jobs_reponse
            ### Removed till here
        return response

    def get_all_jobs(self, jobs_list=None):
        """
        Returns list of all the ETL jobs

        :param jobs_list:
        :return:
        """

        self._logger.info("In {f_name}, getting all jobs.".format(
            f_name=__name__
        ))
        _path = "jobs"
        offset = 1
        next_available = "yes"
        jobs_list = [] if not jobs_list else jobs_list
        while next_available == "yes":
            jobs_response = self.api_wrapper.make_request(_path, fields=None, method='get', headers=None,
                                                          data=None, verify=True, offset=offset)
            if jobs_response.status_code == 200:
                dict_response = text_to_dict(jobs_response.text)
                next_available = dict_response.get("next_available")
                offset = offset + dict_response["count"]
                if dict_response.get("jobs"):
                    jobs_list = jobs_list + dict_response.get("jobs")
            else:
                response = generate_json_reponse(jobs_response)
                return response
        if jobs_list:
            dict_response["jobs"] = jobs_list
            response = generate_json_reponse(dict_response, exitcode=0, message="Generated list of all jobs.")
        else:
            response = generate_json_reponse(None, exitcode=0, message="No jobs found.")
        return response

    def update_extra_resource(self, JobName=None, JobId=None, DatasetAccess=None,
                              ParameterAccess=None, SharedLibraries=None, **kwargs):
        """
        Update the job's extra resource access

        :param JobName: Name of the job
        :param JobId: Id of the job
        :param DatasetAccess: Dataset access to the job. Format must be,

            { 'Owner': list({ 'DatasetName': '<DatasetName>', 'DatasetId': '<DatasetId>' }),
            'ReadOnly': list({ 'DatasetName': '<DatasetName>', 'DatasetId': '<DatasetId>' }) }

        :param ParameterAccess: List of ParameterAccess
        :param SharedLibraries: Name of the shared libraries

        :return:
        """

        self._logger.info("In {f_name}, updating extra resource for job with name {job_name}.".format(
            f_name=__name__, job_name=JobName
        ))

        if not(JobName or JobId):
            self._logger.error("In {f_name}, either JobName or JobId must be passed.".format(f_name=__name__))
            raise Exception("Either JobName or JobId must be passed.")

        self._logger.info("In {f_name}, updating script for job with name {job_name}.".format(
            f_name=__name__, job_name=JobName
        ))

        if not JobId:
            job_details = self._get_job_id_type(JobName=JobName)
            if 'exitcode' not in job_details:
                JobId = job_details['job_id']
            else:
                return job_details

        if JobId:
            _path = 'job_extra_res_path'

            payload = {}
            arguments = locals()

            if arguments['DatasetAccess']:
                payload['DatasetAccess'] = self._validate_dataset_access_dict(arguments['DatasetAccess'])
            else:
                payload['DatasetAccess'] = {
                    'Owner': [],
                    'ReadOnly': []
                }

            # Add Parameter Access
            payload['ParameterAccess'] = arguments['ParameterAccess'] if arguments['ParameterAccess'] else []

            # Create shared libs list
            common_libs_id_list = self._get_common_libs_id_list(arguments['SharedLibraries'])
            payload['SharedLibraries'] = common_libs_id_list

            job_extra_res_response = self.api_wrapper.make_request(_path, fields=JobId,
                                                                   method='post', data=json.dumps(payload))
            response = generate_json_reponse(job_extra_res_response)
        else:
            response = generate_json_reponse(None, exitcode=1, message="No job found with job id {id}.".format(
                id=JobId
            ))
        return response

    def _execute_job(self):
        pass

    def _get_execution_status(self):
        pass

    def _stop_job_execution(self):
        pass

    def _get_valid_libs_list(self, libs_list):
        """
        Returns list of validated lib name

        :param libs_list: list of python libraries
        :return:
        """

        self._logger.debug("In {f_name}, validating if libs {libs} exists.".format(
            f_name=__name__, libs=libs_list
        ))
        if not isinstance(libs_list, list):
            libs_list = [libs_list]
        python_libs_name = []
        for lib in libs_list:
            if not os.path.exists(lib):
                raise Exception("Libs file {file} doesn't exists.".format(file=lib))
            lib_name = lib.split('/')[-1]
            python_libs_name.append(lib_name)
        self._logger.debug("In {f_name}, validated libs.".format(f_name=__name__))
        return python_libs_name

    def add_job_libs(self, JobName, PythonLibs):
        """
        It adds external libs to ETL job

        :param JobName: Name of the job.
        :param PythonLibs: List of python libs to be added.
        :return:
        """

        if PythonLibs:
            self._logger.info("In {f_name}, adding libs {libs} to job {name}.".format(
                f_name=__name__, libs=PythonLibs, name=JobName))
            job_details = self._get_job_id_type(JobName=JobName)
            if 'exitcode' not in job_details:
                job_id = job_details['job_id']
                job_type = job_details['type']
                external_python_libs = job_details['external_python_libs']
                job_python_lib_s3_dir = job_details['job_s3_dir'] + '/libs/python/'

                if external_python_libs:
                    external_python_libs_list = set(external_python_libs.split(','))
                else:
                    external_python_libs_list = set()

                if job_id:
                    _path = "job_libs"
                    # Create list if not in list format
                    if not isinstance(PythonLibs, list):
                        PythonLibs = [PythonLibs]
                    python_libs_name = {}
                    for lib in PythonLibs:
                        if not os.path.exists(lib):
                            raise Exception("Libs file {file} doesn't exists.".format(file=lib))
                        lib_name = lib.split('/')[-1]
                        if lib_name.split('.')[-1] not in self.python_libs_compatibility[job_type]:
                            raise Exception('Lib {file} is not compatible with job type {type}. '
                                            'Supported format is {lib_types}'.
                                            format(file=lib_name,
                                                   type=job_type,
                                                   lib_types=self.python_libs_compatibility[job_type]
                                                   ))
                        python_libs_name[lib_name] = lib

                    for lib_name, lib_path in python_libs_name.items():
                        lib_payload = {
                            'FileName': lib_name
                        }
                        libs_register_response = self.api_wrapper.make_request(_path, fields=job_id,
                                                                               method='post',
                                                                               data=json.dumps(lib_payload))
                        presigned_url = text_to_dict(libs_register_response.text)['PresignedUrl']
                        presigned_upload_response = self._upload_with_presigned_url(presigned_url, lib_path)
                        if presigned_upload_response['exitcode'] != 0:
                            return presigned_upload_response
                        full_lib_url = job_python_lib_s3_dir + lib_name
                        external_python_libs_list.add(full_lib_url)

                        lib_register_payload = {
                            'PythonLibPaths': list(external_python_libs_list)
                        }
                        libs_complete_response = self.api_wrapper.make_request(_path, fields=job_id,
                                                                               method='put',
                                                                               data=json.dumps(lib_register_payload))
                    response = generate_json_reponse(libs_complete_response)

                else:
                    response = generate_json_reponse(None, exitcode=1, message="No job found with job id {id}.".format(
                        id=job_id
                    ))
            else:
                response = job_details
        else:
            response = generate_json_reponse(None, exitcode=1, message="No libs to be added.")
        return response

    def remove_job_libs(self, JobName, PythonLibs=None, RemoveAll=False):
        """
        It removes external libs from ETL job

        :param JobName: Name of the job.
        :param PythonLibs: List of python libs to be added.
        :param RemoveAll: True to remove all libs, Default: False
        :return:
        """

        _path = 'job_libs'

        job_details = self._get_job_id_type(JobName=JobName)
        if 'exitcode' not in job_details:
            job_id = job_details['job_id']
            if RemoveAll:
                self._logger.warning("In {f_name}, removing all the python external libs for job {name}.".format(
                    f_name=__name__, name=JobName))
                libs_list_payload = {
                    'PythonLibPaths': []
                }
            elif PythonLibs:
                if not isinstance(PythonLibs, list):
                    PythonLibs = [PythonLibs]
                self._logger.info("In {f_name}, removing python libs {libs} for job {name}.".format(
                    f_name=__name__, libs=PythonLibs, name=JobName))
                external_python_libs = job_details['external_python_libs']
                job_python_lib_s3_dir = job_details['job_s3_dir'] + '/libs/python/'
                if external_python_libs:
                    existing_external_python_libs_set = set(external_python_libs.split(','))
                else:
                    existing_external_python_libs_set = set()
                libs_list_payload = {
                    'PythonLibPaths': list(existing_external_python_libs_set
                                           - {job_python_lib_s3_dir + lib
                                              for lib in PythonLibs})
                }

            if RemoveAll or PythonLibs:
                libs_remove_all_response = self.api_wrapper.make_request(_path, fields=job_id,
                                                                         method='put',
                                                                         data=json.dumps(libs_list_payload))
                response = generate_json_reponse(libs_remove_all_response)
            else:
                self._logger.info("In {f_name}, No python libs passed to be removed.".format(f_name=__name__))
                response = generate_json_reponse(None, exitcode=0, message="No libs passed to be removed.")
        else:
            response = job_details

        return response

    def create_common_libs(self, LibraryName, PythonLibs, LibraryDescription="Created via Amorphicutils",
                           Keywords=None):
        """
        Creates common libs to be used for ETL

        :param LibraryName: Name of the library
        :param PythonLibs: List of python libs to be added
        :param LibraryDescription: Description of the library
        :param Keywords: Keywords for the package
        :return:
        """

        _path = "common_libs"

        if not re.match("^[A-Za-z0-9-]*$", LibraryName):
            self._logger.error("In {f_name}, name of libs can be alpha numeric including hyphen.".format(
                f_name=__name__))
            raise ValueError("Name can contain alpha numeric including hyphen.")

        self._logger.info("In {f_name}, creating common libs with name {lib_name}.".format(
            f_name=__name__, lib_name=LibraryName
        ))

        if PythonLibs:
            if not isinstance(PythonLibs, list):
                PythonLibs = [PythonLibs]
            if not Keywords:
                Keywords = ["CreatedBy:AmorphicUtils"]
            try:
                self._logger.debug("In {f_name}, Changing library name to lowercase.".format(f_name=__name__))
                LibraryName = LibraryName.lower()

                libs_payload = {
                    'LibraryName': LibraryName,
                    'LibraryDescription': LibraryDescription,
                    'Keywords': Keywords,
                    'Packages': []
                }
                register_libs = self.api_wrapper.make_request(_path, method='POST', data=json.dumps(libs_payload))

                if register_libs.status_code == 200:
                    _path = 'common_libs_details'
                    response = self.update_common_libs(LibraryName=LibraryName, PythonLibs=PythonLibs)
                else:
                    self._logger.error("In {f_name}, failed to register new library with error {err}.".format(
                        f_name=__name__, err=register_libs.text
                    ))
                    response = generate_json_reponse(register_libs)
            except Exception as ex:
                self._logger.error("In {f_name}, failed to create common libs  with error {err}.".format(
                    f_name=__name__, err=ex
                ))
                response = generate_json_reponse(None,
                                                 exitcode=1,
                                                 message="Failed to create common libs  with error {err}.".format(
                                                     err=ex
                                                 ))
        else:
            response = generate_json_reponse(None, exitcode=1, message="No libs available.")
        return response

    def update_common_libs(self, LibraryName, PythonLibs):
        """
        Update the common library

        :param LibraryName: Name of the library
        :param PythonLibs: List of python libraries
        :return:
        """

        self._logger.info("In {f_name}, updating the library with name {name}.".format(
            f_name=__name__, name=LibraryName))
        self._logger.debug("In {f_name}, changing library name to lowercase.".format(f_name=__name__))
        LibraryName = LibraryName.lower()
        _path = 'common_libs_details'
        lib_details_reponse = self.get_common_libs(LibraryName)
        if lib_details_reponse['exitcode'] == 0:
            if not isinstance(PythonLibs, list):
                PythonLibs = [PythonLibs]
            python_libs_name = {}
            libs_id = lib_details_reponse['data']['LibraryId']
            valid_libs = self._get_valid_libs_list(PythonLibs)
            supported_format = [value for sublist in self.python_libs_compatibility.values() for value in sublist]
            for lib, lib_path in zip(valid_libs, PythonLibs):
                if lib.split('.')[-1] not in supported_format:
                    raise Exception('Lib {file} is not compatible. '
                                    'Supported format is {lib_types}'.
                                    format(file=lib, lib_types=supported_format))
                payload = {
                    'LibraryName': lib_details_reponse['data']['LibraryName'],
                    'LibraryDescription': lib_details_reponse['data']['LibraryDescription'],
                    'LibraryId': libs_id,
                    'FileName': lib
                }
                upload_response = self.api_wrapper.make_request(_path,
                                                                fields=libs_id,
                                                                method='post',
                                                                data=json.dumps(payload))
                if upload_response.status_code == 200:
                    self._logger.debug('In {f_name}, updating common library with lib {name}.'.format(
                        f_name=__name__, name=lib
                    ))
                    upload_libs_details = text_to_dict(upload_response.text)
                    upload_path = upload_libs_details['UploadPath']
                    presigned_url = upload_libs_details['PresignedUrl']
                    presigned_upload_response = self._upload_with_presigned_url(presigned_url, lib_path)
                    if presigned_upload_response['exitcode'] != 0:
                        return presigned_upload_response
                    python_libs_name[lib] = upload_path
            # Update libs
            update_libs_payload = {
                'LibraryName': lib_details_reponse['data']['LibraryName'],
                'LibraryDescription': lib_details_reponse['data']['LibraryDescription'],
                'Keywords': lib_details_reponse['data']['Keywords'],
                'Packages': list(set(python_libs_name.values()))
            }
            update_libs_response = self.api_wrapper.make_request(_path,
                                                                 fields=libs_id,
                                                                 method='put',
                                                                 data=json.dumps(update_libs_payload))
            response = generate_json_reponse(update_libs_response)
        else:
            response = lib_details_reponse
        return response

    def delete_common_libs(self, LibraryName):
        """
        Deletes the common library from amorphic

        :param LibraryName: Name of the lib to delete
        :return:
        """

        LibraryName = LibraryName.lower()
        _path = 'common_libs_details'
        lib_details_reponse = self.get_common_libs(LibraryName)
        if lib_details_reponse['exitcode'] == 0:
            self._logger.info('In {f_name}, deleting common library with name {name}.'.format(
                f_name=__name__, name=LibraryName))
            libs_id = lib_details_reponse['data']['LibraryId']
            delete_libs_reponse = self.api_wrapper.make_request(_path, fields=libs_id, method='delete')
            response = generate_json_reponse(delete_libs_reponse)
        else:
            response = lib_details_reponse
        return response

    def get_all_common_libs(self):
        """
        Returns list of all common libs

        :return:
        """

        _path = 'common_libs'

        response = self.api_wrapper.make_request(_path)
        return generate_json_reponse(response)

    def get_common_libs(self, LibraryName):
        """
        Returns details of library

        :param LibraryName: Name of the library
        :return:
        """

        if LibraryName:
            self._logger.info("In {f_name}, getting common libs with name {lib_name}.".format(
                f_name=__name__, lib_name=LibraryName
            ))
            response = self.get_all_common_libs()
            if response['exitcode'] == 0:
                all_libs = response['data']['libraries']
                for libs_details in all_libs:
                    if libs_details['LibraryName'] == LibraryName.lower():
                        response = generate_json_reponse(libs_details, exitcode=0, message='Retrieved library details.')
                        return response
                response = generate_json_reponse(None, exitcode=1, message="No common library found with name {name}".
                                                 format(name=LibraryName.lower()))
        else:
            response = generate_json_reponse(None, 1, "No library name passed.")

        return response
