"""
Class for views
"""

import json

from amorphicutils.api.utils import generate_json_reponse, text_to_dict
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.api.api_common import ApiCommon

# pylint: disable=invalid-name,unused-argument


class Views(ApiCommon):
    """
    Class to call dataset related API
    """

    def __init__(self, api_wrapper):
        ApiCommon.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()
        self.views_param_validation_functions = {
            'ViewName': lambda x: bool(x and isinstance(x, str)),
            'ViewType': lambda x: x in ['standard', 'materialized'],
            'Description': lambda x: bool(x and isinstance(x, str)),
            'TargetLocation': lambda x: str(x) in ["redshift", "s3athena", "auroramysql"],
            'SqlStatement': lambda x: bool(x and isinstance(x, str)),
            'Domain': lambda x: bool(x and isinstance(x, str)),
            'Keywords': lambda x: bool(x and isinstance(x, list))
        }

    def get_all(self, views_list=None):
        """
        Get all the views

        :param views_list:
        :return:
        """
        self._logger.info("In {name}, getting list of all views.".format(name=__name__))
        _path = 'views'
        offset = 1
        next_available = "yes"
        views_list = [] if not views_list else views_list
        while next_available == "yes":
            views_response = self.api_wrapper.make_request(_path, fields=None, method='get', headers=None,
                                                           data=None, verify=True, offset=offset)
            if views_response.status_code == 200:
                dict_response = text_to_dict(views_response.text)
                next_available = dict_response.get("next_available")
                offset = offset + dict_response["count"]
                if dict_response.get("views"):
                    views_list = views_list + dict_response.get("views")
            else:
                response = generate_json_reponse(views_response)
                return response
        if views_list:
            dict_response["views"] = views_list
            response = generate_json_reponse(dict_response, exitcode=0, message="Generated list of all views.")
        else:
            response = generate_json_reponse(None, exitcode=1, message="No views found.")
        return response

    def get(self, ViewName=None, ViewId=None):
        """
        Get the details for view based on ViewName or ViewId

        :param ViewName: Name of the view
        :param ViewId: Id of the view
        :return:
        """

        self._logger.info("In {name}, getting view details for ViewName {v_name}, and ViewId {v_id}.".format(
            name=__name__, v_name=ViewName, v_id=ViewId
        ))

        if not (ViewId or ViewName):
            self._logger.error("In {name}, Either ViewName or ViewId must be passed.".format(name=__name__))
            raise Exception('Either ViewName or ViewId must be passed.')

        if ViewId:
            _path = "view_details"
            view_response = self.api_wrapper.make_request(_path, fields=ViewId, method='get')
            response = generate_json_reponse(view_response)
        else:
            all_views_response = self.get_all()
            if all_views_response['exitcode'] == 0:
                for view in all_views_response['data']['views']:
                    if view['ViewName'] == ViewName:
                        response = self.get(ViewId=view['ViewId'])
                        return response
                response = generate_json_reponse(None, exitcode=1, message="No views found with name {name}.".format(
                    name=ViewName
                ))
            else:
                response = all_views_response
        return response

    def create(self, ViewName, Domain, TargetLocation, SqlStatement, ViewType='standard',
               Description=None, DataClassification=None, Keywords=None, AutoRefresh=True, **view_kwargs):
        """
        Creates the view

        :param ViewName: Name of the view
        :param Domain: Domain for the view
        :param TargetLocation: Target location. Must be one of ['redshift', 's3athena']
        :param SqlStatement: SQL statement for the view
        :param ViewType: Type of the view. Must be one of ['standard'], Default: standard
        :param Description: Description of the view
        :param DataClassification: Data classification for the view
        :param Keywords: Keywords for the view
        :param AutoRefresh: True if want view to be autorefreshed. Default: True
        :param view_kwargs: Extra keyword arguments for view creation

        :return:
        """

        self._logger.info("In {name}, creating view with ViewName {v_name}.".format(
            name=__name__, v_name=ViewName
        ))

        arguments = locals()
        _path = 'views'
        if not Description:
            arguments['Description'] = "Created view using Amorphicutils"
        if not Keywords:
            arguments['Keywords'] = [ViewName]
        if not DataClassification:
            arguments.pop('DataClassification', None)

        for key, value in arguments.items():
            if key in self.views_param_validation_functions.keys():
                if not self.views_param_validation_functions[key](arguments[key]):
                    raise Exception("Failed to validate value for key: {key} with value: {value}".
                                    format(key=key,
                                           value=value))
        arguments['Domain'] = arguments['Domain'].lower()
        arguments.pop('self', None)
        arguments.update(view_kwargs)

        create_response = self.api_wrapper.make_request(operation=_path, method='post', data=json.dumps(arguments))

        return generate_json_reponse(create_response)

    def update(self, Description=None, Keywords=None, DataClassification=None, SqlStatement=None,
               ViewName=None, ViewId=None, AutoRefresh=True):
        """
        Updates an existing view

        :param Description: Description of the view
        :param Keywords: Keywords for the view
        :param DataClassification: Data classification for the view
        :param SqlStatement: SQL statement for the view
        :param ViewName: Name of the view
        :param ViewId: Id of the view
        :param AutoRefresh: True if want view to be autorefreshed. Default: True

        :return:
        """

        self._logger.info("In {name}, updating view details for ViewName {v_name}, and ViewId {v_id}.".format(
            name=__name__, v_name=ViewName, v_id=ViewId
        ))
        arguments = locals()
        _path = 'view_details'
        if not (ViewId or ViewName):
            self._logger.error("In {name}, Either ViewName or ViewId must be passed.".format(name=__name__))
            raise Exception('Either ViewName or ViewId must be passed.')

        if not ViewId:
            view_response = self.get(ViewName=ViewName)
        else:
            view_response = self.get(ViewId=ViewId)

        if view_response['exitcode'] == 0:
            ViewId = view_response['data']['ViewId']
            view_type = view_response['data']['ViewType']
            target_location = view_response['data']['TargetLocation']
        else:
            response = view_response

        if ViewId:
            if not Description:
                arguments['Description'] = view_response['data']['Description']
            if not Keywords:
                arguments['Keywords'] = view_response['data']['Keywords']
            if not SqlStatement:
                arguments['SqlStatement'] = view_response['data']['SqlStatement']
            if not DataClassification:
                arguments['DataClassification'] = view_response['data'].get('DataClassification', None)
                arguments.pop('DataClassification', None)
            arguments.pop('self', None)
            arguments.pop('ViewId', None)
            arguments.pop('ViewName', None)

            if view_type != 'materialized':
                arguments.pop('AutoRefresh', None)
            else:
                arguments.pop('SqlStatement', None)

            update_response = self.api_wrapper.make_request(operation=_path, fields=ViewId,
                                                            method='put', data=json.dumps(arguments))
            response = generate_json_reponse(update_response)

        return response

    def delete(self, ViewName=None, ViewId=None):
        """
        Deletes the view

        :param ViewName: Name of the view
        :param ViewId:  Id of the view

        :return:
        """

        self._logger.info("In {name}, deleting view details for ViewName {v_name}, and ViewId {v_id}.".format(
            name=__name__, v_name=ViewName, v_id=ViewId
        ))

        _path = 'view_details'

        if not (ViewId or ViewName):
            self._logger.error("In {name}, Either ViewName or ViewId must be passed.".format(name=__name__))
            raise Exception('Either ViewName or ViewId must be passed.')

        if not ViewId:
            view_response = self.get(ViewName=ViewName)
            if view_response['exitcode'] == 0:
                ViewId = view_response['data']['ViewId']
            else:
                response = view_response

        if ViewId:
            delete_response = self.api_wrapper.make_request(operation=_path, method='delete', fields=ViewId)
            response = generate_json_reponse(delete_response)

        return response
