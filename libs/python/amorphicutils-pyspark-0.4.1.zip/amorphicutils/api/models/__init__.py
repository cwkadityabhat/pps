import importlib
import os
import sys
from amorphicapi.version_detector import detect_api_version

_version_loaded = False
_real_module = None
selected_version = None

# Declare at top level
__all__ = []


def configure(base_url=None, role_id=None, token=None):
    global _version_loaded, _real_module, selected_version

    try:
        version = detect_api_version(
            base_url, role_id, token
        )  # e.g., "v1", "v2", "v3_1_1"
    except Exception as e:
        version = "v2"  # fallback
        print(
            "[amorphicutils.api] Version detection failed, falling back to {}: {}".format(
                version, e
            )
        )

    print("[amorphicutils.api] Selected version: {}".format(version))

    _real_module = importlib.import_module(
        "amorphicutils.api.models.{}".format(version)
    )
    selected_version = version
    _version_loaded = True

    current_module = sys.modules[__name__]

    # Inject public attributes from versioned module into this module's global namespace
    public_attrs = [attr for attr in dir(_real_module) if not attr.startswith("_")]

    for attr in public_attrs:
        setattr(current_module, attr, getattr(_real_module, attr))

    # Dynamically set __all__ on the module object (required for Python 3.6)
    current_module.__all__ = public_attrs


# Auto-configure from env vars
_url_with_env = os.getenv("AMORPHIC_ENDPOINT_URL_WITH_ENV")
_role_id = os.getenv("AMORPHIC_ROLE_ID")
_api_token = os.getenv("AMORPHIC_API_TOKEN")

if _url_with_env and _role_id and _api_token:
    try:
        print(
            "[amorphicutils.api.models] Auto-configuring models from environment variables."
        )
        configure(_url_with_env, _role_id, _api_token)
    except Exception as e:
        raise ImportError(
            "[amorphicutils.api.models] Failed to auto-configure models from version: {}".format(
                e
            )
        )
