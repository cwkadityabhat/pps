"""
Class for Dataset
"""

from amorphicutils.api.models.v1.datasets import Dataset as V1Dataset

import json
import datetime

from amorphicutils.errors import SchemaDetailsValidationException
from amorphicutils.api.utils import generate_json_reponse, text_to_dict
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.api.api_common import ApiCommon


# pylint: disable=too-many-arguments,invalid-name,too-many-branches,too-many-statements,too-many-locals,unused-argument
# pylint: disable=too-many-nested-blocks


class Dataset(V1Dataset):
    """
    Class to call dataset related API
    """

    def __init__(self, api_wrapper):
        V1Dataset.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()

    def create_domain(
        self, DomainName, DisplayName=None, DomainDescription=None, TenantName=None
    ):
        """
        Creates domain in Amorphic , return success if domain already exists

        :param DomainName: domain name
        :param DisplayName: display name for domain
        :param DomainDescription: description of the domain
        :return:
        """

        self._logger.info(
            "In {name}, creating domain with name {d_name}.".format(
                name=__name__, d_name=DomainName
            )
        )

        domain_response = self.get_domain(DomainName)
        if not domain_response["exitcode"] == 0:
            # Creates domain
            _path = "domains"
            if DomainName.isalnum() and DomainName[0].isalpha():
                payload = {
                    "DomainName": DomainName.lower(),
                    "DisplayName": DisplayName if DisplayName else DomainName,
                    "DomainDescription": (
                        DomainDescription
                        if DomainDescription
                        else "Created via Amorphicutils."
                    ),
                }

                if TenantName:
                    payload["TenantName"] = TenantName

                domain_creation_response = self.api_wrapper.make_request(
                    _path,
                    method="post",
                    headers=None,
                    data=json.dumps(payload),
                    verify=True,
                )

                response = generate_json_reponse(domain_creation_response)
            else:
                response = generate_json_reponse(
                    None,
                    exitcode=1,
                    message="Domain name should be alphanumeric and starts with alphabet.",
                )
        else:
            response = generate_json_reponse(
                domain_response["data"],
                1,
                "Domain {name} already exists with details {details}".format(
                    name=DomainName, details=domain_response["message"]
                ),
            )
        return response

    def create_dataset(
        self,
        DatasetName,
        Domain,
        ConnectionType,
        FileType,
        TargetLocation,
        TableUpdate,
        MalwareDetectionOptions=None,
        Keywords=None,
        DatasetDescription="Created using Amorphicutils",
        IsDataProfilingEnabled="false",
        FileDelimiter=",",
        IsDataValidationEnabled="false",
        SkipFileHeader="false",
        DataClassification=None,
        TargetTablePrepMode="truncate",
        NotificationSettings="all",
        DatasetSchema=None,
        RecordKeys=None,
        DatasetKeyOptions=None,
        LatestRecordIndicator=None,
        PartitionKeys=None,
        DatasetType="internal",
        **kwargs
    ):
        """
        Creates the dataset in Amorphic, returns dataset details if already exists

        :param DatasetName: Dataset name
        :param Domain: Domain under which to create dataset
        :param ConnectionType: Connection type for dataset, must be one of ['api', 's3', 'jdbc', 'ext-fs']
        :param FileType: File type of the input based on target type. Full list is
            ['csv', 'xlsx', 'parquet', 'txt', 'pdf', 'jpg', 'png', 'mp3', 'wav', 'others']
        :param TargetLocation: Target location of dataset, must be from ['redshift', 'auroramysql', 's3athena', 's3']
        :param TableUpdate: Data ingestion type, must be from ['append', 'reload', 'update']
        :param MalwareDetectionOptions: Malware detection in dict format,
            key must be from ['ScanForMalware', 'AllowUnscannableFiles'] and value can be True or False
        :param Keywords: Keywords for the dataset
        :param DatasetDescription: Description of the dataset
        :param IsDataProfilingEnabled: if want to enable data profiling, default: false
        :param FileDelimiter: delimiter for structure data, default: ','
        :param IsDataValidationEnabled: Validate schema for each file for s3athena type dataset. Default: false
        :param SkipFileHeader: true if header exists, default false
        :param DataClassification: Data classification for the dataset
        :param TargetTablePrepMode: Mode for reload type dataset, can be from ['recreate', 'truncate'].
            Default: truncate
        :param NotificationSettings: type of notification settings, default: all
        :param DatasetSchema: schema of the dataset in format of [{'name': 'id', 'type': 'varchar'}]
        :param RecordKeys: record key for table update type update
        :param DatasetKeyOptions: Defines options for SortType, SortKeys, DistType, DistKey
            * SortType: sort type for target type redshift, must be from ['none', 'interleaved', 'compound']
            * SortKeys: sort keys for target type redshift
            * DistType: dist type for target type redshift must be from ['auto', 'even', 'key', 'all']
            * DistKey: dist key type for target type redshift
            * Default: {'SortType': 'none', 'SortKeys':None, 'DistType': 'auto', 'DistKey': ''}
        :param LatestRecordIndicator: latest record key for table update type update,
            default: {"name": "upload_time", "type": "bigint"}
        :param PartitionKeys: List of Dicts of (name, type, rank) to be used as partition
        :param kwargs:
        :return:
        """

        self._logger.info(
            "In {name}, creating dataset with DatasetName {d_name}.".format(
                name=__name__, d_name=DatasetName
            )
        )

        _path = "register_dataset"

        dataset_response = self.get_dataset(DatasetName)
        if not dataset_response["exitcode"] == 0:
            arguments = locals()
            if not arguments["DatasetKeyOptions"]:
                arguments["DatasetKeyOptions"] = {
                    "SortType": "none",
                    "SortKeys": None,
                    "DistType": "auto",
                    "DistKey": "",
                }

            payload, schema_payload = self._get_validated_dataset_payload(arguments)

            # Remove DataClassification as not available
            if not payload["DataClassification"]:
                payload.pop("DataClassification")

            # Add the extra kwargs to payload
            payload.update(**kwargs)

            # Add DatasetType to payload
            payload["DatasetType"] = DatasetType

            # Calling Amorphic API
            headers = {"Content-Type": "text/plain"}

            dataset_creation_response = self.api_wrapper.make_request(
                _path,
                method="post",
                headers=headers,
                data=json.dumps(payload),
                verify=True,
            )

            response = generate_json_reponse(dataset_creation_response)

            if TargetLocation in self.dwh_supported_fileformats.keys():
                if response["exitcode"] == 0:
                    dataset_id = response["data"]["DatasetId"]
                    _path = "dataset_details"
                    dataset_schema_response = self.api_wrapper.make_request(
                        _path,
                        method="put",
                        fields=dataset_id,
                        headers=headers,
                        data=json.dumps(schema_payload),
                        verify=True,
                    )
                    if dataset_schema_response.status_code == 200:
                        response = generate_json_reponse(dataset_creation_response)
                    else:
                        # Delete the dataset to avoid incomplete dataset
                        self.delete_dataset(DatasetName=DatasetName)
                        response = generate_json_reponse(dataset_schema_response)
        else:
            response = generate_json_reponse(
                dataset_response["data"],
                1,
                "Dataset {name} already exists.".format(name=DatasetName),
            )
        return response
