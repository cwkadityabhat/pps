"""
Class for Views
"""

import json

from amorphicutils.api.utils import generate_json_reponse, text_to_dict
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.api.models.v1.views import Views as V1Views
from amorphicutils.api.models.v3.datasets import Dataset
from amorphicutils.api.apiwrapper import ApiWrapper
from amorphicapi.v3.api.datasets_api import DatasetsApi

# pylint: disable=too-many-arguments,invalid-name,too-many-branches,too-many-statements,too-many-locals,unused-argument
# pylint: disable=too-many-nested-blocks


class Views(V1Views):
    """
    Class to call view related API
    """

    def __init__(self, api_wrapper):
        V1Views.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper: ApiWrapper = api_wrapper
        self.core_datasets_api: DatasetsApi = self.api_wrapper.core_api.DatasetsApi
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()
        self.datasets = Dataset(api_wrapper=self.api_wrapper)

    def get_all(self, **kwargs):
        """
        Get all the views

        :param views_list:
        :return:
        """
        self._logger.info("In {name}, getting list of all views.".format(name=__name__))
        _path = "views"
        offset = 1
        next_available = "yes"
        datasets_list = []
        while next_available == "yes":
            dataset_response = self.api_wrapper.make_request(
                _path,
                fields=None,
                method="get",
                headers=None,
                data=None,
                verify=True,
                offset=offset,
                filterExpression="DatasetType:view",
            )
            if dataset_response.status_code == 200:
                dict_response = text_to_dict(dataset_response.text)
                next_available = dict_response.get("next_available")
                offset = offset + dict_response["count"]
                if dict_response.get("datasets"):
                    view_list = []
                    for item in dict_response["datasets"]:
                        item["ViewId"] = item["DatasetId"]
                        item["ViewName"] = item["DatasetName"]
                        view_list.append(item)
                    datasets_list = datasets_list + view_list
            else:
                response = generate_json_reponse(dataset_response)
                break
        if datasets_list:
            dict_response["views"] = datasets_list
            dict_response.pop("datasets", None)
            response = generate_json_reponse(
                dict_response, exitcode=0, message="Generated list of all views."
            )
        else:
            response = generate_json_reponse(
                None, exitcode=1, message="No views found."
            )
        return response

    def get(self, ViewName=None, ViewId=None):
        """
        Get the details for view based on ViewName or ViewId

        :param ViewName: Name of the view
        :param ViewId: Id of the view
        :return:
        """

        self._logger.info("In {name}, getting view details for ViewName {v_name}, and ViewId {v_id}.".format(
            name=__name__, v_name=ViewName, v_id=ViewId
        ))

        if not (ViewId or ViewName):
            self._logger.error(
                "In {name}, Either ViewName or ViewId must be passed.".format(
                    name=__name__
                )
            )
            raise Exception("Either ViewName or ViewId must be passed.")

        if ViewId:
            _path = "view_details"
            dataset_response = self.api_wrapper.make_request(
                _path,
                fields=ViewId,
                method="get",
                headers=None,
                data=None,
                verify=True,
            )

            dataset_dict = text_to_dict(dataset_response.text)
            dataset_dict["ViewId"] = dataset_dict["DatasetId"]
            dataset_dict["ViewName"] = dataset_dict["DatasetName"]
            response = generate_json_reponse(
                dataset_dict, exitcode=0, message="Views details"
            )
        else:
            resource_id_response = self.get_resource_id(
                "datasets", resource_name=ViewName
            )
            if resource_id_response["exitcode"] == 0:
                dataset_id = resource_id_response["data"]["ResourceId"]
                response = self.get(ViewId=dataset_id)
            else:
                response = resource_id_response
                # To be removed in future
                search_response_json = self.datasets.search_dataset(DatasetName=ViewName)
                if search_response_json["exitcode"] == 0:
                    if search_response_json["data"]["total_count"] > 0:
                        for item in search_response_json["data"]["datasets"]:
                            if item["DatasetName"] == ViewName:
                                response = self.get(
                                    ViewName=ViewName, ViewId=item["DatasetId"]
                                )
                            else:
                                response = generate_json_reponse(
                                    None,
                                    exitcode=1,
                                    message="No view found of name {name}".format(
                                        name=ViewName
                                    ),
                                )
                    else:
                        response = generate_json_reponse(
                            None,
                            exitcode=1,
                            message="No view found with name {name}".format(
                                name=ViewName
                            ),
                        )
                else:
                    response = search_response_json
                    # Get all dataset and iterate to find the dataset
                    all_views_response = self.get_all()
                    if all_views_response["exitcode"] == 0:
                        all_dataset = all_views_response["data"]["views"]
                        for dataset in all_dataset:
                            if dataset["DatasetName"] == ViewName:
                                response = self.get(
                                    ViewName==ViewName,
                                    ViewId=dataset["DatasetId"],
                                )
                                break
                    else:
                        response = all_views_response
                # Removed till here
        return response

    def create(
        self,
        ViewName,
        Domain,
        TargetLocation,
        SqlStatement,
        ViewType="standard",
        Description=None,
        DataClassification=None,
        Keywords=None,
        AutoRefresh=True,
        **view_kwargs
    ):
        """
        Creates the view

        :param ViewName: Name of the view
        :param Domain: Domain for the view
        :param TargetLocation: Target location. Must be one of ['redshift', 's3athena']
        :param SqlStatement: SQL statement for the view
        :param ViewType: Type of the view. Must be one of ['standard'], Default: standard
        :param Description: Description of the view
        :param DataClassification: Data classification for the view
        :param Keywords: Keywords for the view
        :param AutoRefresh: True if want view to be autorefreshed. Default: True
        :param view_kwargs: Extra keyword arguments for view creation

        :return:
        """

        self._logger.info(
            "In {name}, creating view with ViewName {v_name}.".format(
                name=__name__, v_name=ViewName
            )
        )

        arguments = locals()
        _path = "views"
        arguments["DatasetDescription"] = arguments.get("Description", "Created view using Amorphicutils")
        arguments.pop("Description", None)
        if not Keywords:
            arguments["Keywords"] = [ViewName]
        if not DataClassification:
            arguments.pop("DataClassification", None)

        for key, value in arguments.items():
            if key in self.views_param_validation_functions.keys():
                if not self.views_param_validation_functions[key](arguments[key]):
                    raise Exception(
                        "Failed to validate value for key: {key} with value: {value}".format(
                            key=key, value=value
                        )
                    )
        arguments["DatasetName"] = ViewName
        arguments.pop("ViewName", None)
        arguments["DatasetType"] = "view"
        arguments["Domain"] = arguments["Domain"].lower()
        arguments.pop("self", None)
        arguments.update(view_kwargs)

        # create_response = self.core_datasets_api.datasets_post(
        #     role_id=self.api_wrapper.role_id,
        #     dataset_metadata=text_to_dict(json.dumps(arguments)),
        # )
        # Create the view using the API wrapper

        create_response = self.api_wrapper.make_request(
            operation=_path, method="post", data=json.dumps(arguments)
        )

        return generate_json_reponse(create_response)

    def update(self, Description=None, Keywords=None, DataClassification=None, SqlStatement=None,
               ViewName=None, ViewId=None, AutoRefresh=True):
        """
        Updates an existing view

        :param Description: Description of the view
        :param Keywords: Keywords for the view
        :param DataClassification: Data classification for the view
        :param SqlStatement: SQL statement for the view
        :param ViewName: Name of the view
        :param ViewId: Id of the view
        :param AutoRefresh: True if want view to be autorefreshed. Default: True

        :return:
        """

        self._logger.info("In {name}, updating view details for ViewName {v_name}, and ViewId {v_id}.".format(
            name=__name__, v_name=ViewName, v_id=ViewId
        ))
        arguments = locals()
        _path = 'update_dataset'
        if not (ViewId or ViewName):
            self._logger.error("In {name}, Either ViewName or ViewId must be passed.".format(name=__name__))
            raise Exception('Either ViewName or ViewId must be passed.')

        if not ViewId:
            view_response = self.get(ViewName=ViewName)
        else:
            view_response = self.get(ViewId=ViewId)


        if view_response['exitcode'] == 0:
            ViewId = view_response['data']['DatasetId']
            view_type = view_response['data']['DatasetType']
            target_location = view_response['data']['TargetLocation']
        else:
            response = view_response

        if ViewId:
            arguments["DatasetDescription"] = view_response["data"]["DatasetDescription"] if not Description else Description
            arguments.pop("Description", None)
            if not Keywords:
                arguments['Keywords'] = view_response['data']['Keywords']
            if not SqlStatement:
                arguments['SqlStatement'] = view_response['data']['SqlStatement']
            if not DataClassification:
                arguments['DataClassification'] = view_response['data'].get('DataClassification', None)
                arguments.pop('DataClassification', None)
            arguments.pop('self', None)
            # arguments['DatasetId'] = ViewId
            arguments.pop('ViewId', None)
            # arguments["DatasetName"] = view_name
            arguments.pop('ViewName', None)

            if view_type != 'materialized':
                arguments.pop('AutoRefresh', None)
            else:
                arguments.pop('SqlStatement', None)

            update_response = self.api_wrapper.make_request(operation=_path, fields=ViewId,
                                                            method='put', data=json.dumps(arguments))
            response = generate_json_reponse(update_response)

        return response

    def delete(self, ViewName=None, ViewId=None):
        """
        Deletes the view

        :param ViewName: Name of the view
        :param ViewId:  Id of the view

        :return:
        """

        self._logger.info(
            "In {name}, deleting view details for ViewName {v_name}, and ViewId {v_id}.".format(
                name=__name__, v_name=ViewName, v_id=ViewId
            )
        )

        _path = "view_details"

        if not (ViewId or ViewName):
            self._logger.error(
                "In {name}, Either ViewName or ViewId must be passed.".format(
                    name=__name__
                )
            )
            raise Exception("Either ViewName or ViewId must be passed.")

        if not ViewId:
            view_response = self.get(ViewName=ViewName)
            if view_response["exitcode"] == 0:
                ViewId = view_response["data"]["DatasetId"]
            else:
                response = view_response

        if ViewId:
            delete_response = self.api_wrapper.make_request(
                operation=_path, method="delete", fields=ViewId
            )
            response = generate_json_reponse(delete_response)

        return response
