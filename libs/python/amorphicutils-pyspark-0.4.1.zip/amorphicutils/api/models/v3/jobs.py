"""
Class for Jobs
"""

from amorphicutils.api.models.v1.jobs import Jobs as V1Jobs

import json

from amorphicutils.api.utils import generate_json_reponse
from amorphicutils.amorphiclogging import Log4j


# pylint: disable=too-many-arguments,invalid-name,too-many-branches,too-many-statements,too-many-locals,unused-argument
# pylint: disable=too-many-nested-blocks


class Jobs(V1Jobs):
    """
    Class to call jobs related API
    """

    def __init__(self, api_wrapper):
        V1Jobs.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()

        # pylint: disable=too-many-locals,too-many-arguments

    # pylint: disable=too-many-branches
    def _get_jobs_payload(self, arguments):

        if "Description" in arguments:
            if not arguments["Description"]:
                arguments["Description"] = "Created using Amorphicutils."
            else:
                # Python 2: Convert unicode to string
                arguments["Description"] = str(arguments["Description"])

        # Validate the arguments
        for k, validation_func in self.jobs_param_validation_functions.items():
            if not validation_func(arguments[k]):
                raise ValueError(
                    "Failed to validate value for key: {key} for value: {value}".format(
                        key=k, value=arguments[k]
                    )
                )

        if arguments["DatasetAccess"]:
            arguments["DatasetAccess"] = self._validate_dataset_access_dict(
                arguments["DatasetAccess"]
            )
        else:
            arguments["DatasetAccess"] = {"Owner": [], "ReadOnly": []}

        payload = {
            "JobName": arguments["JobName"],
            "Description": arguments["Description"],
            "ETLJobType": arguments["ETLJobType"],
            "NetworkConfiguration": arguments["NetworkConfiguration"],
            "MaxRetries": arguments["MaxRetries"],
            "DatasetAccess": arguments["DatasetAccess"],
            "JobBookmarkOption": arguments["JobBookmarkOption"],
            "IsAutoScalingEnabled": arguments["IsAutoScalingEnabled"],
        }

        if arguments["Keywords"]:
            payload["Keywords"] = arguments["Keywords"]
        else:
            payload["Keywords"] = [arguments["JobName"]]
        if arguments["Timeout"]:
            payload["Timeout"] = arguments["Timeout"]
        if arguments["MaxConcurrentRuns"]:
            payload["MaxConcurrentRuns"] = arguments["MaxConcurrentRuns"]
        if arguments["DefaultArguments"]:
            payload["DefaultArguments"] = arguments["DefaultArguments"]
        # Add Parameter Access
        if arguments["ParameterAccess"]:
            payload["ParameterAccess"] = arguments["ParameterAccess"]

        # Validate python and glue compatibility
        if (
            str(arguments["GlueVersion"]) == "0.9"
            and str(arguments["PythonVersion"]) == "3"
        ):
            raise ValueError(
                "Glue version 0.9 is not compatible with Python version 3. Please use Glue 1.0 version."
            )

        payload["GlueVersion"] = str(arguments["GlueVersion"])
        payload["PythonVersion"] = str(arguments["PythonVersion"])

        # Validate pythonshell and glue allocation capacity
        if arguments["ETLJobType"] == "pythonshell":
            if arguments["AllocatedCapacity"] and arguments[
                "AllocatedCapacity"
            ] not in [0.0625, 1]:
                raise ValueError(
                    "Valid allocated_capacity for ETLJobType python is 0.0625 or 1."
                )

            payload["AllocatedCapacity"] = arguments["AllocatedCapacity"]
            del payload["GlueVersion"]

        elif arguments["ETLJobType"] == "spark":
            if arguments["WorkerType"] and not arguments["NumberOfWorkers"]:
                raise Exception("Both WorkerType and num_workers should be passed.")
            if arguments["WorkerType"] and arguments["NumberOfWorkers"]:
                if arguments["NumberOfWorkers"] < 2:
                    raise ValueError("Number of worker should be greater than 1.")
                payload["WorkerType"] = arguments["WorkerType"]
                payload["NumberOfWorkers"] = arguments["NumberOfWorkers"]
            elif arguments["AllocatedCapacity"]:
                if arguments["AllocatedCapacity"] < 2:
                    raise ValueError("Allocated capacity should be greater than 1.")
                payload["AllocatedCapacity"] = arguments["AllocatedCapacity"]
            else:
                payload["AllocatedCapacity"] = 2

        if arguments["kwargs"]:
            self._logger.warning(
                "In {f_name}, following arguments {args} are not defined in function "
                "and thus not used under payload.".format(
                    f_name=__name__, args=arguments["kwargs"]
                )
            )

        return payload
