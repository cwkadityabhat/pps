"""
Class for Dataset
"""

from amorphicutils.api.models.v1.datasets import Dataset as V1Dataset

import json

from amorphicutils.api.utils import generate_json_reponse
from amorphicutils.amorphiclogging import Log4j


# pylint: disable=too-many-arguments,invalid-name,too-many-branches,too-many-statements,too-many-locals,unused-argument
# pylint: disable=too-many-nested-blocks


class Dataset(V1Dataset):
    """
    Class to call dataset related API
    """

    def __init__(self, api_wrapper):
        V1Dataset.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()

    def create_domain(
        self, DomainName, DisplayName=None, DomainDescription=None, TenantName=None
    ):
        """
        Creates domain in Amorphic , return success if domain already exists

        :param DomainName: domain name
        :param DisplayName: display name for domain
        :param DomainDescription: description of the domain
        :return:
        """

        self._logger.info(
            "In {name}, creating domain with name {d_name}.".format(
                name=__name__, d_name=DomainName
            )
        )

        domain_response = self.get_domain(DomainName)
        if not domain_response["exitcode"] == 0:
            # Creates domain
            _path = "domains"
            if DomainName.isalnum() and DomainName[0].isalpha():
                payload = {
                    "DomainName": DomainName.lower(),
                    "DisplayName": DisplayName if DisplayName else DomainName,
                    "DomainDescription": (
                        DomainDescription
                        if DomainDescription
                        else "Created via Amorphicutils."
                    ),
                }

                if TenantName:
                    payload["TenantName"] = TenantName

                domain_creation_response = self.api_wrapper.make_request(
                    _path,
                    method="post",
                    headers=None,
                    data=json.dumps(payload),
                    verify=True,
                )

                response = generate_json_reponse(domain_creation_response)
            else:
                response = generate_json_reponse(
                    None,
                    exitcode=1,
                    message="Domain name should be alphanumeric and starts with alphabet.",
                )
        else:
            response = generate_json_reponse(
                domain_response["data"],
                1,
                "Domain {name} already exists with details {details}".format(
                    name=DomainName, details=domain_response["message"]
                ),
            )
        return response
