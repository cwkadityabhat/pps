"""
Class for Jobs
"""

from amorphicutils.api.models.v1.jobs import Jobs as V1Jobs

import json

from amorphicutils.api.utils import generate_json_reponse
from amorphicutils.amorphiclogging import Log4j


# pylint: disable=too-many-arguments,invalid-name,too-many-branches,too-many-statements,too-many-locals,unused-argument
# pylint: disable=too-many-nested-blocks


class Jobs(V1Jobs):
    """
    Class to call jobs related API
    """

    def __init__(self, api_wrapper):
        V1Jobs.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()
