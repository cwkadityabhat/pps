"""
Class for Views
"""

from amorphicutils.api.models.v1.views import Views as V1Views

import json

from amorphicutils.api.utils import generate_json_reponse
from amorphicutils.amorphiclogging import Log4j


# pylint: disable=too-many-arguments,invalid-name,too-many-branches,too-many-statements,too-many-locals,unused-argument
# pylint: disable=too-many-nested-blocks


class Views(V1Views):
    """
    Class to call view related API
    """

    def __init__(self, api_wrapper):
        V1Views.__init__(self, api_wrapper=api_wrapper)
        self.api_wrapper = api_wrapper
        self.log4j = Log4j()
        self._logger = self.log4j.get_logger()
