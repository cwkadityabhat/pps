"""
Loading Amorphic wrapper
"""

from .amorphic import Amorphic
